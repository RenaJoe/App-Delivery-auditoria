import { Component, OnInit } from '@angular/core';
import { PedidosService } from 'src/app/services/pedidos.service';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { AlertController, MenuController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pedidos-list',
  templateUrl: './pedidos-list.page.html',
  styleUrls: ['./pedidos-list.page.scss'],
})
export class PedidosListPage implements OnInit {
  pedidos = [];
  loandingPage: boolean;

  constructor(
    private pedidosService: PedidosService,
    private storage: NativeStorage,
    private alertController: AlertController,
    private router: Router,
    private menuCtrl: MenuController
  ) {
    this.menuCtrl.enable(true);
    this.loandingPage = false;

  }

  ngOnInit() {
  }
  ionViewDidEnter() {
    this.getPedidos()
  }
  getPedidos() {
    this.pedidosService.getPedidos().subscribe((res: any) => {
      console.log(res);
      this.pedidos.splice(0, this.pedidos.length)
      for (const iterator of res.data) {
        if (iterator.estado != "Recibido") {

          this.pedidos.push(iterator)
        }
      }
      console.log(this.pedidos);
      if(this.pedidos.length < 1){
        this.loandingPage = true;
      }else{
        this.loandingPage = false;
      }
    })
  }

  takePedido(id_pedido: number) {
    this.storage.getItem("token").then((res: any) => {
      console.log(res.user);

      this.pedidosService.createRepartidorPedidos(id_pedido, res.user.id).subscribe((res: any) => {
        console.log(res);
        this.getPedidos()
        this.presentAlert("Atención", "Usted ha tomado este pedido", "Debe acercarce al establecimiento a retirar la orden")
      }, (error: any) => {
        console.log(error);
        if (error.status == 401) {
          this.getPedidos()
          this.presentAlert("Atención", "No se ha tomado el pedido", "El pedido ya ha sido tomado por otro repartidor")
        }
      })

    })

  }


  async presentAlert(header, subHeader, message) {
    const alert = await this.alertController.create({

      header: header,
      subHeader: subHeader,
      message: message,
      buttons: ['OK']
    });

    await alert.present();
  }

  goToMisPedidos() {
    this.router.navigate(["mis-pedidos"])
  }

}
