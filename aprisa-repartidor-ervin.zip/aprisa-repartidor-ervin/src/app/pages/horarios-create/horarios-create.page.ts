import { AlertService } from './../../services/alert.service';
import { LoadingController, NavController } from '@ionic/angular';
import { HorarioService } from './../../services/horario.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-horarios-create',
  templateUrl: './horarios-create.page.html',
  styleUrls: ['./horarios-create.page.scss'],
})
export class HorariosCreatePage implements OnInit {
  loading: any
  horario = {
    id_usuario: 0,
    dia: "",
    inicio: "2021-08-08T08:00:00.350-05:00",
    fin: "2021-08-08T08:00:00.350-05:00"
  }
  constructor(
    private actRoute: ActivatedRoute,
    private horarioService: HorarioService,
    private loadingCtrl: LoadingController,
    private navController: NavController,
    private alertService: AlertService
      ) { }

  ngOnInit() {
    this.horario.id_usuario = parseInt(this.actRoute.snapshot.paramMap.get("id_usuario"))
  }

  async createhorario() {
    console.log(this.horario);

    let inicio = this.getHourAndMinutes(this.horario.inicio)
    let fin = this.getHourAndMinutes(this.horario.fin)

    this.horario.inicio = inicio
    this.horario.fin = fin

    this.loading = await this.loadingCtrl.create({
      message: 'Por favor espere...'
    });
    await this.loading.present();

    this.horarioService.create(this.horario).subscribe(res => {
      console.log(res);
      this.navController.navigateRoot("horarios-list")
      this.loading.dismiss()
    }, error => {
      console.log(error);
      this.horario.inicio = "2021-08-08T08:00:00.350-05:00"
      this.horario.fin = "2021-08-08T08:00:00.350-05:00"
      this.loading.dismiss()
      this.alertService.presentToast("El día escogido ya existe")
    })
  }

  getHourAndMinutes(date) {
    let d = date.split('T')[1];
    let m = d.split(':')[0];
    let n = d.split(':')[1];
    return m + ":" + n;
  }
}
