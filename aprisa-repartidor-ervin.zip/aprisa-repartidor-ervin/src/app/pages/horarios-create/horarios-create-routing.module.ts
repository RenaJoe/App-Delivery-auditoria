import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HorariosCreatePage } from './horarios-create.page';

const routes: Routes = [
  {
    path: '',
    component: HorariosCreatePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HorariosCreatePageRoutingModule {}
