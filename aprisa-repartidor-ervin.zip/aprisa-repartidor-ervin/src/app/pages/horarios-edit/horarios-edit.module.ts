import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HorariosEditPageRoutingModule } from './horarios-edit-routing.module';

import { HorariosEditPage } from './horarios-edit.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HorariosEditPageRoutingModule
  ],
  declarations: [HorariosEditPage]
})
export class HorariosEditPageModule {}
