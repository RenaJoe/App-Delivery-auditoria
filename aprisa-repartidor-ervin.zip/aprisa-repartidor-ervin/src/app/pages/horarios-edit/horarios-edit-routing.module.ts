import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HorariosEditPage } from './horarios-edit.page';

const routes: Routes = [
  {
    path: '',
    component: HorariosEditPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HorariosEditPageRoutingModule {}
