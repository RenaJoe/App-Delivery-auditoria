import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HorariosListPageRoutingModule } from './horarios-list-routing.module';

import { HorariosListPage } from './horarios-list.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HorariosListPageRoutingModule
  ],
  declarations: [HorariosListPage]
})
export class HorariosListPageModule {}
