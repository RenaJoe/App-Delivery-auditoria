import { SocketWebService } from './../../services/socket-web.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {
  GoogleMaps,
  GoogleMap,
  GoogleMapsEvent,
  GoogleMapOptions,
  CameraPosition,
  MarkerOptions,
  Marker,
  Environment,
  LocationService,
  MyLocation,
  ILatLng,
  LatLngBounds
} from '@ionic-native/google-maps';
import { Platform, AlertController } from '@ionic/angular';
import { Geolocation, GeolocationOptions } from '@ionic-native/geolocation/ngx';
import { GeolocalizacionService } from 'src/app/services/geolocalizacion.service';
import { PedidosService } from 'src/app/services/pedidos.service';
@Component({
  selector: 'app-map',
  templateUrl: './map.page.html',
  styleUrls: ['./map.page.scss'],
})
export class MapPage implements OnInit, OnDestroy {
  id_pedido: number
  map: GoogleMap;
  location = {
    latitud: 0,
    longitud: 0
  }
  clickIniciar: Boolean = false
  watch1


  markerRepartidor: Marker
  markerNegocio: Marker
  markerUser: Marker

  constructor(
    private actRoute: ActivatedRoute,
    private platform: Platform,
    private geolocation: Geolocation,
    private geolocalizacionService: GeolocalizacionService,
    private alertController: AlertController,
    private pedidosService: PedidosService,
    private sockteWebService: SocketWebService
  ) { }

  ngOnInit() {
    this.platform.ready().then((res: any) => {
      console.log(res);
      this.id_pedido = parseInt(this.actRoute.snapshot.paramMap.get("id_pedido"))
      this.loadMap()

    })
  }
  getRepartidorLocation() {


    let options: GeolocationOptions = { enableHighAccuracy: true }
    this.watch1 = this.geolocation.watchPosition(options).subscribe((data) => {

      this.location.latitud = data.coords.latitude;
      this.location.longitud = data.coords.longitude;
      let payload = {
        location: this.location,
        pedido_id: this.id_pedido
      }
      this.sockteWebService.emitEvent(payload)
      console.log(data)
    });
  }

  loadMap() {

    LocationService.getMyLocation().then((myLocation: MyLocation) => {

      // console.log(myLocation);

      let mapOptions: GoogleMapOptions = {
        controls: {
          compass: true,
          myLocation: true,
          myLocationButton: true,
          mapToolbar: false,
          zoom: true
        },
        camera: {
          target: myLocation.latLng,
          zoom: 16,
          tilt: 30
        },
        styles: [

          // {
          //   featureType: 'poi.business',
          //   // elementType: 'labels.text.fill',
          //   stylers: [{ visibility: "off" }]
          // },

        ]
      }

      this.map = GoogleMaps.create('map_canvas', mapOptions);
      this.getInfoPedido(this.id_pedido)
    });
  }

  startNavigation() {
    this.clickIniciar = true
    let body = {
      "id_pedido": 0,
      "latitud": 0,
      "longitud": 0,
      "estado": ""
    }

    this.getRepartidorLocation()

    body.id_pedido = this.id_pedido
    body.latitud = this.location.latitud
    body.longitud = this.location.longitud;
    body.estado = "enviando"
    this.geolocalizacionService.createGeolocation(body).subscribe((res: any) => {
      console.log(res)

    })
    console.log("enviando coordenadas")
  }
  stopNavigation() {
    this.watch1.unsubscribe();
    let body = {
      "id_pedido": 0,
      "latitud": 0,
      "longitud": 0,
      "estado": ""
    }
    body.latitud = this.location.latitud
    body.longitud = this.location.longitud;
    body.id_pedido = this.id_pedido
    body.estado = "completado"
    console.log("envio detenido")
    this.geolocalizacionService.createGeolocation(body).subscribe((res: any) => {  //temporal mientras testing map
      console.log(res)
    });

    this.pedidosService.updateEstadoPedido(
      this.id_pedido,
      "Completado",
      "Orden completada",
      "Su orden ha sido completada, hasta pronto !!! "  //descomentar para cambiar el estado a entregado
    ).subscribe((res: any) => {
      console.log(res);
      this.clickIniciar = false;
      this.presentAlert("Atención", "Orden Completada", "El pedido ha sido completado")
    })

  }
  async presentAlert(header, subHeader, message) {
    const alert = await this.alertController.create({

      header: header,
      subHeader: subHeader,
      message: message,
      buttons: ['OK']
    });

    await alert.present();
  }

  getInfoPedido(id_pedido) {
    this.pedidosService.getPedidoById(id_pedido).subscribe((res: any) => {
      console.log(res);
      this.markerNegocio = this.map.addMarkerSync({
        // title: 'Su pedido se encuentra aquí',
        icon: './assets/icon/storefront.png',
        animation: 'DROP',
        position: {
          lat: parseFloat(res.data.negocio.latitud),
          lng: parseFloat(res.data.negocio.longitud)
        }
      });
      this.markerUser = this.map.addMarkerSync({
        // title: 'Su pedido se encuentra aquí',
        icon: './assets/icon/iconDireccion.png',
        animation: 'DROP',
        position: {
          lat: parseFloat(res.data.direccion.latitud),
          lng: parseFloat(res.data.direccion.longitud)
        }
      });

      let path: ILatLng[] = [
        {
          lat: parseFloat(res.data.negocio.latitud),
          lng: parseFloat(res.data.negocio.longitud)
        },
        {
          lat: parseFloat(res.data.direccion.latitud),
          lng: parseFloat(res.data.direccion.longitud)
        }
      ];
      let latLngBounds = new LatLngBounds(path);
      this.map.moveCamera({
        target: latLngBounds
      })

    })
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    if (this.watch1) {

      this.watch1.unsubscribe();
    }
  }

}
