import { Injectable } from '@angular/core';
import { EnvService } from './env.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PedidosService {

  constructor(
    private envService: EnvService,
    private http: HttpClient
  ) { }

  getPedidos() {
    return this.http.get(this.envService.API_URL + "pedidos")
  }

  createRepartidorPedidos(id_pedido, id_usuario) {
    let body = {
      "id_usuario": "",
      "id_pedido": ""
    }
    body.id_pedido = id_pedido
    body.id_usuario = id_usuario

    return this.http.post(this.envService.API_URL + "repartidorPedidos", body)
  }

  getPedidosByRepartidor(id_user) {
    return this.http.get(this.envService.API_URL + "repartidorPedidos/" + id_user)
  }

  updateEstadoPedido(id_pedido, estado, header, content) {
    let body = {
      estado: "",
      header: "",
      content: ""
    }
    body.estado = estado
    body.header = header
    body.content = content

    return this.http.put(this.envService.API_URL + "updateEstadoPedido/" + id_pedido, body)
  }
  getPedidoById(id_pedido: number) {
    return this.http.get(this.envService.API_URL + "pedidos/" + id_pedido)
  }
}
