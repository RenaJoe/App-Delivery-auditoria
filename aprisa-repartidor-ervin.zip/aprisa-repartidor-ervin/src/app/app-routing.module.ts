import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'folder/:id',
    loadChildren: () => import('./folder/folder.module').then(m => m.FolderPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'pedidos-list',
    loadChildren: () => import('./pages/pedidos-list/pedidos-list.module').then( m => m.PedidosListPageModule),canActivate : [AuthGuard]
  },
  {
    path: 'mis-pedidos',
    loadChildren: () => import('./pages/mis-pedidos/mis-pedidos.module').then( m => m.MisPedidosPageModule)
  },
  {
    path: 'map',
    loadChildren: () => import('./pages/map/map.module').then( m => m.MapPageModule)
  },  {
    path: 'horarios-list',
    loadChildren: () => import('./pages/horarios-list/horarios-list.module').then( m => m.HorariosListPageModule)
  },
  {
    path: 'horarios-create',
    loadChildren: () => import('./pages/horarios-create/horarios-create.module').then( m => m.HorariosCreatePageModule)
  },
  {
    path: 'horarios-edit',
    loadChildren: () => import('./pages/horarios-edit/horarios-edit.module').then( m => m.HorariosEditPageModule)
  }




];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
