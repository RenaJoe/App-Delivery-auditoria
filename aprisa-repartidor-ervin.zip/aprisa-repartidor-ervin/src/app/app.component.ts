import { UpdateService } from './services/update.service';
import { Component, OnInit } from '@angular/core';

import { Platform, LoadingController, MenuController, NavController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AuthService } from './services/auth.service';
import { AlertService } from './services/alert.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  public selectedIndex = 0;
  loading: any;
  public appPages = [
    {
      title: 'Inicio',
      url: '/pedidos-list',
      icon: 'home'
    },
    {
      title: 'Mis pedidos',
      url: '/mis-pedidos',
      icon: 'list'
    },
    {
      title: 'Horarios',
      url: 'horarios-list',
      icon: 'calendar'
    },
  ];
  public labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private loadingCtrl: LoadingController,
    public authService: AuthService,
    private alertService: AlertService,
    private menuCtrl: MenuController,
    private navCtrl: NavController,
    private router: Router,
    private updateService: UpdateService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      this.updateService.checkForUpdate()
    });
  }

  ngOnInit() {
    const path = window.location.pathname.split('folder/')[1];
    if (path !== undefined) {
      this.selectedIndex = this.appPages.findIndex(page => page.title.toLowerCase() === path.toLowerCase());
    }
  }

  async logout() {

    this.loading = await this.loadingCtrl.create({
      message: 'Por favor espere...'
    });
    await this.loading.present();

    this.authService.logout().subscribe(
      data => {
        // this.alertService.presentToast(data['message']);
        this.alertService.presentToast("Sesión cerrada correctamente");
        this.loading.dismiss();
        this.menuCtrl.enable(false);
      },
      error => {
        console.log(error);
        // this.alertService.presentToast(error['message']);
        this.loading.dismiss();
        this.authService.invalidateToken();
        this.router.navigate(["login"]);
      },
      () => {
        this.navCtrl.navigateRoot('/login');
      }
    );
  }
}
