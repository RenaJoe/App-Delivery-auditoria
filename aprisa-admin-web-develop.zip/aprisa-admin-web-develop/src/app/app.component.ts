import { Component } from '@angular/core';
import { AuthService } from './auth/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'aprisa-web';

  constructor( private _auth: AuthService) { 
    if (localStorage.getItem('tokenAprisaUser')) {
      _auth.isLoggedIn = true;
      _auth.token = localStorage.getItem('tokenAprisaUser');
    }else{
      _auth.isLoggedIn = false;
    }
  }

}


