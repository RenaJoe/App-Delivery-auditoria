export interface OrderAllResponse {
    data:    Order[];
    message: string;
    status:  number;
}
export interface OrderOneResponse {
    data:    Order;
    message: string;
    status:  number;
}

export interface Order {
    id_pedido:          number;
    id_usuario:         number;
    id_negocio:         number;
    id_direccion:       number;
    id_facturacion:     number;
    subtotal:           string;
    costo_envio:        string;
    total:              string;
    observaciones:      string;
    tipo_pago:          string;
    estado:             string;
    id_device:          string;
    user:               User;
    negocio:            Negocio;
}

export interface Negocio {
    id_negocio:            number;
    id_usuario:            number;
    id_tipo_servicio:      number;
    nombre:                string;
    codigo:                string;
    latitud:               string;
    longitud:              string;
    foto:                  string;
    direccion:             string;
    telefono:              string;
}

export interface User {
    id:                number;
    id_rol:            number;
    nombre:            string;
    apellido:          string;
    cedula:            string;
    telefono:          string;
    foto:              string;
    estado:            string;
    email:             string;
    id_device:         null;
}
