export interface BannerAllResponse {
    data: Banner[];
    message: string;
    status: number;
}

export interface BannerOneResponse {
    data: Banner;
    message: string;
    status: number;
}

export interface Banner {
    id_banner: number;
    id_producto: number;
    id_negocio: number;
    foto: string;
    redireccion: string;
}
