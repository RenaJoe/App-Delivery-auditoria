export interface ParameterAllResponse {
    data: Parameter[];
    message: string;
    status: number;
}

export interface ParameterOneResponse {
    data: Parameter;
    message: string;
    status: number;
}

export interface Parameter {
    id_parametro: number;
    nombre: string;
    variable_name: string;
    valor: string;

}
