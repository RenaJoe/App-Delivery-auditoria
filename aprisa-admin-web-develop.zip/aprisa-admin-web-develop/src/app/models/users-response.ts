import { User } from "./order-response";

export interface UserAllResponse {
    data: User[];
    message: string;
    status: number;
}
export interface UserOneResponse {
    data: User;
    message: string;
    status: number;
}

