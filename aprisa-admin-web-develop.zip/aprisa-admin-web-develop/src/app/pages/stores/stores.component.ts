import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StoresService } from 'src/app/services/stores.service';

@Component({
  selector: 'app-stores',
  templateUrl: './stores.component.html',
  styleUrls: ['./stores.component.scss'],
})
export class StoresComponent implements OnInit {
  store = [];
  empty = false;

  constructor(
    private storeServices: StoresService,
    private router: Router) {
    this.getNegocios();
  }

  ngOnInit(): void {}

  getNegocios() {
    this.storeServices.getNegocios().subscribe((res: any) => {
      console.log(res);
      this.store = res.data;
      if (this.store.length == 0) {
        this.empty = true;
      }
    });
  }

  goStore(id) {
    this.router.navigateByUrl('pages/editStore/'+id)
  }
}
