import { Component, OnInit } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/storage';
import { ActivatedRoute } from '@angular/router';
import { SUCCESS_ALERT_TITLE, UPDATE_SUCCESS_MESSAGE } from 'src/app/conf/messages';
import { MapService } from 'src/app/services/map.service';
import { StoresService } from 'src/app/services/stores.service';
import { AlertsService } from '../../../services/alerts.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss'],
})
export class EditComponent implements OnInit {
  protected mapS: any;
  marker;
  imgCarga: boolean = false;
  id_store: number;
  progressBarValue: number = 0;
  store = {
    id_negocio: 0,
    id_usuario: 0,
    id_tipo_servicio: 1,
    nombre: '',
    codigo: '',
    foto: '',
    direccion: '',
    telefono: '',
    latitud: 0.3449803,
    longitud: -78.1258634,
  };
 
  constructor(
    private activateRoute: ActivatedRoute,
    private storage: AngularFireStorage,
    private map: MapService,
    private storeService: StoresService,
    private _alert: AlertsService
  ) {
    this.id_store = parseInt(
      this.activateRoute.snapshot.paramMap.get('id_negocio')
    );
  }

  ngOnInit(): void {
    this.getNegocio();
  }

  getNegocio() {
    this.storeService.getNegocioById(this.id_store).subscribe((res: any) => {
      this.store = res.data;
    });
  }


  uploadImg(evento) {
    if (evento.target.files.length > 0) {
      let nameImg = new Date().getTime().toString();
      let file = evento.target.files[0];

      let extFile = file.name
        .toString()
        .substring(file.name.toString().lastIndexOf('.'));

      let ruteFile = 'fotoStore/' + nameImg + extFile;

      this.imgCarga = true;
      const reference = this.storage.ref(ruteFile);
      const task = reference.put(file);

      task.then((objeto) => {
        reference.getDownloadURL().subscribe((url) => {
          this.store.foto = url;
        });
      });

      task.percentageChanges().subscribe((porcentaje) => {
        this.progressBarValue = parseInt(porcentaje.toString());
      })
    }
  }

  markerDragEnd(event: google.maps.MouseEvent) {
    this.store.latitud = event.latLng.lat();
    this.store.longitud = event.latLng.lng();
  }



  save() {
    if (!this.store) {
    } else {
      this.storeService
        .updateStore(this.id_store, this.store)
        .subscribe((res: any) => {
          this._alert.sweetAletGenericSuccess(
            SUCCESS_ALERT_TITLE,
            UPDATE_SUCCESS_MESSAGE
          );
        });
    }
  }
}
