import { BannerService } from './../../services/banner.service';
import { StoresService } from 'src/app/services/stores.service';
import { Component, OnInit } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/storage';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductsService } from 'src/app/services/products.service';
import { AlertsService } from 'src/app/services/alerts.service';
import { Banner } from 'src/app/models/banners-response';
import {
  SUCCESS_ALERT_TITLE,
  UPDATE_SUCCESS_MESSAGE,
  SAVE_SUCCESS_MESSAGE
} from 'src/app/conf/messages';
@Component({
  selector: 'app-banners',
  templateUrl: './banners.component.html',
  styleUrls: ['./banners.component.scss']
})
export class BannersComponent implements OnInit {
  formBanner: FormGroup;
  editable: boolean = false;
  imgCarga: boolean = false;
  progressBarValue: number = 0;
  stores = [];
  products = [];
  banners: Banner[] = [];
  empty = false;
  id_banner = 0;
  constructor(
    private fb: FormBuilder,
    private storage: AngularFireStorage,
    private storeServices: StoresService,
    private productService: ProductsService,
    private _alert: AlertsService,
    private bannersService: BannerService
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.getBanners()
    this.getNegocios()
    this.getProducts()
    this.editable = false;
  }

  initForm() {
    this.formBanner = this.fb.group({
      id_producto: '',
      id_negocio: '',
      redireccion: ['', Validators.required],
      foto: ['', Validators.required],
    });
  }

  getNegocios() {
    this.storeServices.getNegocios().subscribe((res: any) => {
      console.log(res);
      this.stores = res.data;

    });
  }

  getProducts() {
    this.productService.getAll().subscribe((res: any) => {
      console.log(res);
      this.products = res.data
    })
  }

  getBanners() {
    this.bannersService.getAllWithNegocioAndProducto().subscribe(res => {
      console.log(res);

      this.banners = res.data
      if (this.banners.length == 0) {
        this.empty = true;
      } else {
        this.empty = false
      }
    })
  }

  clearForm() {
    this.editable = false;
    this.imgCarga = false;
    this.initForm();
  }

  getItem(banner) {
    this.editable = true;
    this.imgCarga = true;
    this.formBanner = this.fb.group({
      id_producto: '',
      id_negocio: '',
      redireccion: ['', Validators.required],
      foto: ['', Validators.required],
    });

    this.formBanner.controls['id_producto'].setValue(banner.id_producto);
    this.formBanner.controls['id_negocio'].setValue(banner.id_negocio);
    this.formBanner.controls['redireccion'].setValue(banner.redireccion);
    this.formBanner.controls['foto'].setValue(banner.foto);
    this.id_banner = banner.id_banner;
  }

  create() {
    if (this.formBanner.invalid) {
      return;
    } else {
      console.log(this.formBanner.value);

      this.bannersService.create(this.formBanner.value).subscribe((res) => {
        console.log(res);

        this._alert.sweetAletGenericSuccess(
          SUCCESS_ALERT_TITLE,
          SAVE_SUCCESS_MESSAGE
        );
        this.getBanners();
      });
    }
  }

  update() {
    if (this.formBanner.invalid) {
      return
    } else {

      this.bannersService.update(this.id_banner, this.formBanner.value).subscribe((res) => {
        console.log(res);

        this._alert.sweetAletGenericSuccess(
          SUCCESS_ALERT_TITLE,
          UPDATE_SUCCESS_MESSAGE
        )
        this.getBanners()
      })
    }
  }

  delete(banner) {
    this.bannersService.delete(banner.id_banner).subscribe(res => {
      console.log(res);
      this._alert.sweetAletGenericSuccess(
        SUCCESS_ALERT_TITLE,
        UPDATE_SUCCESS_MESSAGE
      )
      this.getBanners()
    })
  }

  uploadImg(evento) {
    if (evento.target.files.length > 0) {
      let nameImg = new Date().getTime().toString();
      let file = evento.target.files[0];

      let extFile = file.name
        .toString()
        .substring(file.name.toString().lastIndexOf('.'));

      let ruteFile = 'Banners/' + nameImg + extFile;

      this.imgCarga = true;
      const reference = this.storage.ref(ruteFile);
      const task = reference.put(file);

      task.then((objeto) => {
        reference.getDownloadURL().subscribe((url) => {
          this.formBanner.controls['foto'].setValue(url);
        });
      });

      task.percentageChanges().subscribe((porcentaje) => {
        this.progressBarValue = parseInt(porcentaje.toString());
      })
    }
  }
}
