import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CarriersComponent } from './carriers/carriers.component';
import { OrdersComponent } from './orders/orders.component';
import { ParametersComponent } from './parameters/parameters.component';
import { StoresComponent } from './stores/stores.component';
import { UsersComponent } from './users/users.component';
import { PagesRoutingModule } from './pages-routing.module';
import { CreateComponent } from './stores/create/create.component';
import { EditComponent } from './stores/edit/edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AngularFireModule } from '@angular/fire';
import { AngularFireStorageModule } from '@angular/fire/storage';
import { environment } from 'src/environments/environment';

import { AgmCoreModule } from '@agm/core';
import { PagesComponent } from './pages.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { ChartsModule } from 'ng2-charts';
import { LoadingComponent } from '../components/loading/loading.component';
import { ProgressBarModule } from 'angular-progress-bar';
import { BannersComponent } from './banners/banners.component';

@NgModule({
  declarations: [
    StoresComponent,
    CreateComponent,
    EditComponent,
    ParametersComponent,
    OrdersComponent,
    UsersComponent,
    CarriersComponent,
    DashboardComponent,
    PagesComponent,
    LoadingComponent,
    BannersComponent
  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireStorageModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBYDnhJ_TYUGdQUiFL-8hcSfaezzhATzwk'
    }),
    ChartsModule,
    ProgressBarModule
  ],
  bootstrap: [PagesComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class PagesModule { }
