import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { StoresComponent } from './stores/stores.component';
import { CarriersComponent } from './carriers/carriers.component';
import { OrdersComponent } from './orders/orders.component';
import { UsersComponent } from './users/users.component';
import { ParametersComponent } from './parameters/parameters.component';
import { CreateComponent } from './stores/create/create.component';
import { EditComponent } from './stores/edit/edit.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { BannersComponent } from './banners/banners.component';


const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'stores', component: StoresComponent },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'carriers', component: CarriersComponent },
      { path: 'banners', component: BannersComponent },
      { path: 'orders', component: OrdersComponent },
      { path: 'users', component: UsersComponent },
      { path: 'parameters', component: ParametersComponent },
      {
        path: 'createStore', component: CreateComponent
      },
      {
        path: 'editStore/:id_negocio', component: EditComponent
      },
      { path: '**', redirectTo: 'dashboard' },
    ],
  },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
