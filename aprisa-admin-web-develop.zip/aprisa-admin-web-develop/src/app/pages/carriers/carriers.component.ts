import { UsersService } from './../../services/users.service';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/order-response';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertsService } from 'src/app/services/alerts.service';
import {
  SUCCESS_ALERT_TITLE,
  UPDATE_SUCCESS_MESSAGE,
} from 'src/app/conf/messages';
import { SAVE_SUCCESS_MESSAGE } from '../../conf/messages';
import { AngularFireStorage } from '@angular/fire/storage';

@Component({
  selector: 'app-carriers',
  templateUrl: './carriers.component.html',
  styleUrls: ['./carriers.component.scss'],
})
export class CarriersComponent implements OnInit {
  users: User[] = [];
  empty = false;
  formCarrier: FormGroup;
  id_carrier = 0;
  editable: boolean = false;
  imgCarga: boolean = false;
  progressBarValue: number = 0;

  constructor(
    private userService: UsersService,
    private fb: FormBuilder,
    private _alert: AlertsService,
    private _user: UsersService,
    private storage: AngularFireStorage
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.getUsers();
    this.editable = false;
  }

  getUsers() {
    this.userService.getAllCarriers().subscribe((res) => {
      console.log(res.data);

      this.users = res.data;
      if (this.users.length == 0) {
        this.empty = true;
      }
    });
  }

  initForm() {
    this.formCarrier = this.fb.group({
      nombre: ['', [Validators.required]],
      apellido: ['', [Validators.required]],
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
      cedula: ['', [Validators.required]],
      telefono: ['', [Validators.required]],
      direccion: ['', [Validators.required]],
      ciudad: ['', [Validators.required]],
      tipo_vehiculo: ['', [Validators.required]],
      foto: '',
    });
  }

  clearForm() {
    this.editable = false;
    this.imgCarga = false;
    this.initForm();
  }

  getItem(user) {
    this.editable = true;
    this.imgCarga = true;
    this.formCarrier = this.fb.group({
      nombre: ['', [Validators.required]],
      apellido: ['', [Validators.required]],
      email: ['', [Validators.required]],
      cedula: ['', [Validators.required]],
      telefono: ['', [Validators.required]],
      direccion: '',
      ciudad: ['', [Validators.required]],
      tipo_vehiculo: ['', [Validators.required]],
      foto: '',
    });

    this.id_carrier = user.id;
    console.log(user.datos_adicionales.ciudad);
    
    try {
      this.formCarrier.controls['nombre'].setValue(user.nombre);
      this.formCarrier.controls['apellido'].setValue(user.apellido);
      this.formCarrier.controls['email'].setValue(user.email);
      this.formCarrier.controls['cedula'].setValue(user.cedula);
      this.formCarrier.controls['telefono'].setValue(user.telefono);
      this.formCarrier.controls['foto'].setValue(user.foto);
      this.formCarrier.controls['datos_adicionales.ciudad'].setValue(
        user.datos_adicionales.ciudad
      );
      this.formCarrier.controls['datos_adicionales.tipo_vehiculo'].setValue(
        user.datos_adicionales.tipo_vehiculo
      );
    } catch (error) {}
  }

  update() {
    console.log(this.formCarrier.value);

    if (this.formCarrier.invalid) {
      return;
    } else {
      this._user
        .updateCarrier(this.id_carrier, this.formCarrier.value)
        .subscribe((res) => {
          this._alert.sweetAletGenericSuccess(
            SUCCESS_ALERT_TITLE,
            UPDATE_SUCCESS_MESSAGE
          );
          this.getUsers();
        });
    }
  }

  create() {
    if (this.formCarrier.invalid) {
      return;
    } else {
      this._user.registerCarrier(this.formCarrier.value).subscribe((res) => {
        this._alert.sweetAletGenericSuccess(
          SUCCESS_ALERT_TITLE,
          SAVE_SUCCESS_MESSAGE
        );
        this.getUsers();
      });
    }
  }

  uploadImg(evento) {
    if (evento.target.files.length > 0) {
      let nameImg = new Date().getTime().toString();
      let file = evento.target.files[0];

      let extFile = file.name
        .toString()
        .substring(file.name.toString().lastIndexOf('.'));

      let ruteFile = 'fotoCarrier/' + nameImg + extFile;

      this.imgCarga = true;
      const reference = this.storage.ref(ruteFile);
      const task = reference.put(file);

      task.then((objeto) => {
        reference.getDownloadURL().subscribe((url) => {
          this.formCarrier.controls['foto'].setValue(url);
        });
      });

      task.percentageChanges().subscribe((porcentaje) => {
        this.progressBarValue = parseInt(porcentaje.toString());
      });
    }
  }
}
