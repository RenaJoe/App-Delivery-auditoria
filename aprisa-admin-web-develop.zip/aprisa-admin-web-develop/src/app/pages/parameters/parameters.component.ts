import { ParametersService } from './../../services/parameters.service';
import { Component, OnInit } from '@angular/core';
import { Parameter } from 'src/app/models/parameter-response';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Params } from '@angular/router';
import {
  SUCCESS_ALERT_TITLE,
  UPDATE_SUCCESS_MESSAGE,
} from 'src/app/conf/messages';
import { AlertsService } from '../../services/alerts.service';

@Component({
  selector: 'app-parameters',
  templateUrl: './parameters.component.html',
  styleUrls: ['./parameters.component.scss'],
})
export class ParametersComponent implements OnInit {
  parameters: Parameter[] = [];
  empty = false;
  id_parameter = 0;
  formParameter: FormGroup;

  constructor(
    private parametersService: ParametersService,
    private fb: FormBuilder,
    private _alert: AlertsService
  ) {}

  ngOnInit(): void {
    this.initForm();
    this.getParameters();
  }

  getParameters() {
    this.parametersService.getAll().subscribe((res) => {
      this.parameters = res.data;
      if (this.parameters.length == 0) {
        this.empty = true;
      }
    });
  }
  initForm() {
    this.formParameter = this.fb.group({
      nombre: ['', [Validators.required]],
      valor: ['', [Validators.required]],
    });
  }

  getItem(parameter: Params) {
    this.formParameter.controls['nombre'].setValue(parameter.nombre);
    this.formParameter.controls['valor'].setValue(parameter.valor);
    this.id_parameter = parameter.id_parametro;
  }

  update() {
    if (this.formParameter.invalid) {
      return;
    } else {
      this.parametersService
        .updateParameter(this.id_parameter, this.formParameter.value)
        .subscribe((res) => {
          this._alert.sweetAletGenericSuccess(
            SUCCESS_ALERT_TITLE,
            UPDATE_SUCCESS_MESSAGE
          );
          this.getParameters()
        });
        
    }
  }
}
