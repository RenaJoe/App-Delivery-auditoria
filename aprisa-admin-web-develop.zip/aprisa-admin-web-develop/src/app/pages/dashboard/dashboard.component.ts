import { Component, OnInit, ViewChild } from '@angular/core';
import { OrdersService } from 'src/app/services/orders.service';
import { StoresService } from 'src/app/services/stores.service';
import { UsersService } from 'src/app/services/users.service';

import { BaseChartDirective } from 'ng2-charts';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  @ViewChild(BaseChartDirective, { static: true }) chart: BaseChartDirective;

  users = 0;
  carriers = 0;
  stores = 0;
  orders = [];
  
  // ChartJS

   lineChartData: any[] = [
    {
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      label: 'Pedidos',
    },
  ];

  public lineChartLabels: any[] = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre',
  ];

  public lineChartOptions: any & { annotation: any } = {
    responsive: true,
    scales: {
      // We use this empty structure as a placeholder for dynamic theming.
      xAxes: [{}],
      yAxes: [
        {
          id: 'y-axis-0',
          position: 'left',
        },
        {
          id: 'y-axis-1',
          position: 'right',
        },
      ],
    },
    annotation: {
      annotations: [
        {
          type: 'line',
          mode: 'vertical',
          scaleID: 'x-axis-0',
          value: 'March',
          borderColor: 'orange',
          borderWidth: 2,
          label: {
            enabled: true,
            fontColor: 'orange',
            content: 'LineAnno',
          },
        },
      ],
    },
  };

  public lineChartColors: any[] = [
    {
      // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)',
    },
  ];

  public lineChartLegend = true;
  public lineChartType: any = 'line';

  constructor(
    private _stores: StoresService,
    private _users: UsersService,
    private _orders: OrdersService
  ) {}

  ngOnInit(): void {
    this.getUsers();
    this.getCarriers();
    this.getNegocios();
    this.getOrders();
  }

  // events
  public chartClicked({
    event,
    active,
  }: {
    event: MouseEvent;
    active: {}[];
  }): void {}

  public chartHovered({
    event,
    active,
  }: {
    event: MouseEvent;
    active: {}[];
  }): void {}

  getUsers() {
    this._users.getAllCarriers().subscribe((res) => {
      this.carriers = res.data.length;
    });
  }

  getCarriers() {
    this._users.getAllUsers().subscribe((res) => {
      this.users = res.data.length;
    });
  }

  getNegocios() {
    this._stores.getNegocios().subscribe((res: any) => {
      this.stores = res.data.length;
    });
  }

  getOrders() {
    this._orders.getAll().subscribe((res) => {
      this.orders = res.data;
      console.log(this.orders);
      let nombreMes = '';
      let aux = 0;
      for (const iterator of this.orders) {
        let fechaComoCadena = iterator.updated_at;
        let numeroMes = new Date(fechaComoCadena).getMonth();
        nombreMes = this.lineChartLabels[numeroMes];
        if (nombreMes == this.lineChartLabels[numeroMes]) {
          aux++;
        }
        this.lineChartData[0].data[numeroMes] = aux;
        this.chart.update();
      }

      nombreMes = '';
    });
  }
}
