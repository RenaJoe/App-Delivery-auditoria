import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss']
})
export class PagesComponent implements OnInit {
  userName = '';
  user:any;
  constructor(private _auth:AuthService, private router: Router) { 
  }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem('tokenAprisaUser'))
    this.userName = `${this.user.user.nombre}`
    
  }

  
  logout() {
    this._auth.logout().subscribe(
      data => {
        this.router.navigate(["auth/login"]);
      },
      error => {
        this._auth.invalidateToken();
        //this.router.navigate(["auth/login"]);
        location.reload()
      })
  }


}
