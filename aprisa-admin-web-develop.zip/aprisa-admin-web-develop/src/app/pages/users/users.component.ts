import { UsersService } from './../../services/users.service';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/order-response';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AlertsService } from 'src/app/services/alerts.service';
import { SUCCESS_ALERT_TITLE, UPDATE_SUCCESS_MESSAGE } from 'src/app/conf/messages';
import { AngularFireStorage } from '@angular/fire/storage';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  users: User[] = [];
  empty = false;
  formUser: FormGroup;
  id_user = 0;
  progressBarValue: number = 0;

  constructor(
    private userService: UsersService,
    private fb: FormBuilder,
    private _alert: AlertsService,
    private _user: UsersService,
    private storage: AngularFireStorage
  ) { }

  ngOnInit(): void {
    this.getUsers()
    this.initForm()
  }
  initForm(){
    this.formUser = this.fb.group({
      nombre: ['', [Validators.required]],
      apellido: ['', [Validators.required]],
      email: ['', [Validators.required]],
      cedula: ['', [Validators.required]],
      telefono: ['', [Validators.required]],
      foto: '',
    });
  }

  clearForm() {
    this.formUser.reset();
  }

  getItem(user) {
    this.formUser.controls['nombre'].setValue(user.nombre);
    this.formUser.controls['apellido'].setValue(user.apellido);
    this.formUser.controls['email'].setValue(user.email);
    this.formUser.controls['cedula'].setValue(user.cedula);
    this.formUser.controls['telefono'].setValue(user.telefono);
    this.formUser.controls['foto'].setValue(user.foto);
    this.id_user = user.id;    
    
  }

  getUsers() {
    this.userService.getAllUsers().subscribe(res => {
      console.log(res.data);
      
      this.users = res.data
      if (this.users.length == 0) {
        this.empty = true;
      }
    })
  }

  update() {
    if (this.formUser.invalid) {
      return;
    } else {
      this._user
        .updateCarrier(this.id_user, this.formUser.value)
        .subscribe((res) => {
          this._alert.sweetAletGenericSuccess(
            SUCCESS_ALERT_TITLE,
            UPDATE_SUCCESS_MESSAGE
          );
          this.getUsers();
        });
    }
  }

  uploadImg(evento) {
    if (evento.target.files.length > 0) {
      let nameImg = new Date().getTime().toString();
      let file = evento.target.files[0];

      let extFile = file.name
        .toString()
        .substring(file.name.toString().lastIndexOf('.'));

      let ruteFile = 'fotoUser/' + nameImg + extFile;
      const reference = this.storage.ref(ruteFile);
      const task = reference.put(file);

      task.then((objeto) => {
        reference.getDownloadURL().subscribe((url) => {
          this.formUser.controls['foto'].setValue(url);
        });
      });

      task.percentageChanges().subscribe((porcentaje) => {
        this.progressBarValue = parseInt(porcentaje.toString());
      })
    }
  }
}
