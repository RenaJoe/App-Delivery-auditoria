import { HttpClient } from '@angular/common/http';
import { EnvService } from './env.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(
    private envService: EnvService,
    private http: HttpClient
  ) { }

  getAll() {
    return this.http.get(this.envService.API_URL + "productos")
  }
}
