import { UserAllResponse } from './../models/users-response';
import { HttpClient } from '@angular/common/http';
import { EnvService } from './env.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UsersService {
  constructor(private envService: EnvService, private http: HttpClient) {}

  getAllUsers() {
    return this.http.get<UserAllResponse>(
      this.envService.API_URL + 'auth/allUsers'
    );
  }

  getAllCarriers() {
    return this.http.get<UserAllResponse>(
      this.envService.API_URL + 'auth/allRepartidores'
    );
  }

  registerCarrier(carrier) {
    return this.http.post(
      this.envService.API_URL + 'auth/registerRepartidor',
      carrier
    );
  }

  updateCarrier(id_carrier, carrier) {
    return this.http.put(
      this.envService.API_URL + `auth/updateRepartidor/${id_carrier}`,
      carrier
    );
  }

}
