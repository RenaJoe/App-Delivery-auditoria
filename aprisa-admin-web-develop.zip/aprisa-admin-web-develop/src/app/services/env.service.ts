import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EnvService {

  // API_URL= 'https://aprisa-backend.herokuapp.com/api/'
  API_URL= 'https://apirest.aprisa.com.ec/public/api/'

  constructor() { }
}
