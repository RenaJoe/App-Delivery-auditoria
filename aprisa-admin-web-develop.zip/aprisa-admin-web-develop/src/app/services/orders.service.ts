import { OrderAllResponse } from './../models/order-response';
import { HttpClient } from '@angular/common/http';
import { EnvService } from './env.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {

  constructor(
    private envService: EnvService,
    private http: HttpClient
  ) { }

  getAll() {
    return this.http.get<OrderAllResponse>(this.envService.API_URL + "pedidos")
  }
}
