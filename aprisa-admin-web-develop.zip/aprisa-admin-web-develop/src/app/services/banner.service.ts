import { Banner, BannerAllResponse, BannerOneResponse } from './../models/banners-response';
import { HttpClient } from '@angular/common/http';
import { EnvService } from './env.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BannerService {

  constructor(
    private envService: EnvService,
    private http: HttpClient
  ) { }

  getAll() {
    return this.http.get<BannerAllResponse>(this.envService.API_URL + "banners")
  }
  getAllWithNegocioAndProducto() {
    return this.http.get<BannerAllResponse>(this.envService.API_URL + "bannersWithNegocioProducto")
  }

  create(banner: Banner) {
    return this.http.post<BannerOneResponse>(this.envService.API_URL + "banners", banner)
  }

  update(id_banner: number, banner: Banner) {
    return this.http.put<BannerOneResponse>(this.envService.API_URL + "banners/" + id_banner, banner)
  }

  delete(id_banner: number) {
    return this.http.delete<BannerOneResponse>(this.envService.API_URL + "banners/" + id_banner)
  }
}
