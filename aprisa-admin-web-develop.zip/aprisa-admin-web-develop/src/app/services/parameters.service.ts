import { Parameter, ParameterAllResponse } from './../models/parameter-response';
import { HttpClient } from '@angular/common/http';
import { EnvService } from './env.service';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ParametersService {

  constructor(
    private envService: EnvService,
    private http: HttpClient
  ) { }
  getAll() {
    return this.http.get<ParameterAllResponse>(this.envService.API_URL + "parametros")
  }

  updateParameter(idParam, body){
    return this.http.put(this.envService.API_URL + `parametros/${idParam}`, body);
  }
}
