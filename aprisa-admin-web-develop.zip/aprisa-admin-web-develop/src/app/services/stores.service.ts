import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from './env.service';

@Injectable({
  providedIn: 'root'
})
export class StoresService {

  constructor(
    private http: HttpClient,
    private envService: EnvService
) { }

  getNegocios() {
    return this.http.get(this.envService.API_URL + "negocios")
  }
  getNegocioById(id_negocio: number) {
    return this.http.get(this.envService.API_URL + "negocios/" + id_negocio)
  }
  updateStore(id_negocio, negocio) {
    return this.http.put(this.envService.API_URL + "negocios/" + id_negocio, negocio)
  }
  createNegocio(negocio) {
    return this.http.post(this.envService.API_URL + "negocios", negocio)
  }

}
