import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ERROR_ALERT_TITLE } from 'src/app/conf/messages';
import { AlertsService } from 'src/app/services/alerts.service';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  formLogin: FormGroup;
  loading: boolean = false;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private _alert: AlertsService,
    private _auth: AuthService
  ) {}

  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.formLogin = this.fb.group({
      email: [
        '',
        [
          Validators.required,
          Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,3}$'),
        ],
      ],
      password: ['', Validators.required],
    });
  }

  save() {
    if (this.formLogin.invalid) {
      return;
    } else {
      this.loading = true;
      this._auth.login(this.formLogin.value).subscribe(
        (res) => {
          this.router.navigateByUrl('/pages/dasboard');
        },
        (error) => {
          this.loading = false;
          this._alert.sweetAletGenericWarning(
            ERROR_ALERT_TITLE,
            'Las credenciales son incorrectas'
          );
        }
      );
    }
  }
}
