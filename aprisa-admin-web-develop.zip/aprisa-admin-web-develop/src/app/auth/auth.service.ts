import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from '../services/env.service';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn: boolean = false;
  token: any;
  constructor(private http: HttpClient, private env: EnvService) { }

  register(body) {
    return this.http.post(this.env.API_URL + 'auth/register', body);
  }

  login(body){
    return this.http
    .post(this.env.API_URL + 'auth/login', body)
    .pipe(
      tap((token) => {
        console.log(token);
        localStorage.setItem('tokenAprisaUser', JSON.stringify(token))
        this.token = token;
        this.isLoggedIn = true;
        return token;
      })
    );
  }

  logout() {
    const headers = new HttpHeaders({
      'Authorization': this.token["token_type"] + " " + this.token["access_token"]
    });
    return this.http.get(this.env.API_URL + 'auth/logout', { headers: headers })
      .pipe(
        tap(data => {
          localStorage.removeItem("tokenAprisaUser");
          this.isLoggedIn = false;
          delete this.token;
          return data;
        })
      )
  }

  invalidateToken() {
    localStorage.removeItem("tokenAprisaUser");
  }
}
