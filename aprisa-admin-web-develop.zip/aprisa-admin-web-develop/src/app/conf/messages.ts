export const SAVE_SUCCESS_MESSAGE = 'Registro guardado correctamente';
export const UPDATE_SUCCESS_MESSAGE = 'Registro actualizado correctamente';

export const SUCCESS_ALERT_TITLE = 'Exitoso';

export const ERROR_ALERT_TITLE = '!! Atención !!';
export const DELETE_ERROR_MESSAGE = 'Error al eliminar';