export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyB59XjDhccWLdRp0ofxSl88I1HltcEMSos",
    authDomain: "aprisa-app.firebaseapp.com",
    databaseURL: "https://aprisa-app.firebaseio.com",
    projectId: "aprisa-app",
    storageBucket: "aprisa-app.appspot.com",
    messagingSenderId: "991215118239",
    appId: "1:991215118239:web:b41d40c8affbe7990cffaa",
    measurementId: "G-8VPYRFY0NT"
  }
};
