if image picker crash replace 
```
com.android.support:appcompat-v7:27+
```
in the file platforms/android/project.properties