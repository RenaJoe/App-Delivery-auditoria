import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from './env.service';

@Injectable({
  providedIn: 'root'
})
export class HorarioService {

  constructor(
    private http: HttpClient,
    private envService: EnvService
  ) { }

  getAllByusuario(id_usuario: number) {
    return this.http.get(this.envService.API_URL + "horariosRepartidorByUserId/" + id_usuario)
  }

  create(horario) {
    return this.http.post(this.envService.API_URL + "horariosRepartidor", horario)
  }
  getById(id_horario) {
    return this.http.get(this.envService.API_URL + "horariosRepartidor/" + id_horario)
  }
  update(id_horario, horario) {
    return this.http.put(this.envService.API_URL + "horariosRepartidor/" + id_horario, horario)
  }
  delete(id_horario) {
    return this.http.delete(this.envService.API_URL + "horariosRepartidor/" + id_horario)
  }
}
