import { Market } from '@ionic-native/market/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvService } from './env.service';
import { Platform, AlertController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})

export class UpdateService {

  constructor(
    private envService: EnvService,
    private http: HttpClient,
    private appVersion: AppVersion,
    private platform: Platform,
    private alertCtlr: AlertController,
    private market: Market
  ) {
    this.platform.resume.subscribe(() => {
      this.checkForUpdate()
    })
  }

  checkForUpdate() {
    this.http.get(this.envService.API_URL + "versionRepartidor").subscribe(async (info: any) => {
      const versionNumber = await this.appVersion.getVersionNumber()
      const splittedVersion = versionNumber.split('.')
      const serverVersion = info.data.valor.split('.')
      if (serverVersion[0] > splittedVersion[0]) {
        this.presentAlert("Atención", "Hay una nueva versión disponible, descárgala ahora para disfrutar todo su contenido")
      } else if (serverVersion[1] > splittedVersion[1]) {
        this.presentAlert("Atención", "Hay una nueva versión disponible, descárgala ahora para disfrutar todo su contenido")
      } else if (serverVersion[2] > splittedVersion[2]) {
        this.presentAlert("Atención", "Hay una nueva versión disponible, descárgala ahora para disfrutar todo su contenido")
      }
    })
  }

  openPlayStore() {
    this.market.open('com.aprisa.repartidor')
  }

  async presentAlert(header, message) {
    const buttons: any = []
    buttons.push({
      text: 'Descargar',
      handler: () => {
        this.openPlayStore()
      }
    })
    const alert = await this.alertCtlr.create({
      header,
      message,
      backdropDismiss: false,
      buttons
    })
    await alert.present()
  }
}
