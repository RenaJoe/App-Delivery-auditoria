import { AlertService } from './../../services/alert.service';
import { LoadingController, NavController } from '@ionic/angular';
import { HorarioService } from './../../services/horario.service';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-horarios-edit',
  templateUrl: './horarios-edit.page.html',
  styleUrls: ['./horarios-edit.page.scss'],
})
export class HorariosEditPage implements OnInit {

  loading: any
  horario = {
    id_horario_repartidor: 0,
    id_negocio: 0,
    dia: "",
    inicio: "2021-08-08T08:00:00.350-05:00",
    fin: "2021-08-08T08:00:00.350-05:00"
  }
  constructor(
    private actRoute: ActivatedRoute,
    private horarioService: HorarioService,
    private loadingCtrl: LoadingController,
    private navController: NavController,
    private alertService: AlertService
  ) { }

  ngOnInit() {
    this.horario.id_horario_repartidor = parseInt(this.actRoute.snapshot.paramMap.get("id_horario_repartidor"))
    console.log(this.horario);
    this.horarioService.getById(this.horario.id_horario_repartidor).subscribe((res: any) => {
      console.log(res);
      this.horario = res.data
    })
  }

  async updateHorario() {
    this.loading = await this.loadingCtrl.create({
      message: 'Por favor espere...'
    });
    await this.loading.present();
    console.log(this.horario);

    this.horarioService.update(this.horario.id_horario_repartidor, this.horario).subscribe((res: any) => {
      this.navController.navigateRoot("horarios-list")
      this.loading.dismiss()
    }, error => {
      this.loading.dismiss()
      this.alertService.presentToast("El día escogido ya existe")
    })
  }
  getHourAndMinutes(date) {
    let d = date.split('T')[1];
    let m = d.split(':')[0];
    let n = d.split(':')[1];
    return m + ":" + n;
  }
}
