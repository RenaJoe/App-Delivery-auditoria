import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { HorariosEditPage } from './horarios-edit.page';

describe('HorariosEditPage', () => {
  let component: HorariosEditPage;
  let fixture: ComponentFixture<HorariosEditPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HorariosEditPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(HorariosEditPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
