import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PedidosListPageRoutingModule } from './pedidos-list-routing.module';

import { PedidosListPage } from './pedidos-list.page';
import { ResourcesModule } from '../../components/resources.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PedidosListPageRoutingModule,
    ResourcesModule
  ],
  declarations: [PedidosListPage]
})
export class PedidosListPageModule {}
