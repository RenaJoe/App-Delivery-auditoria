import { Component, OnInit } from '@angular/core';
import { PedidosService } from 'src/app/services/pedidos.service';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mis-pedidos',
  templateUrl: './mis-pedidos.page.html',
  styleUrls: ['./mis-pedidos.page.scss'],
})
export class MisPedidosPage implements OnInit {
  pedidos = [];
  loandingPage: boolean;

  constructor(
    private pedidosService: PedidosService,
    private storage: NativeStorage,
    private alertController: AlertController,
    private router: Router
  ) { 
    this.loandingPage = false;

  }

  ngOnInit() {
  }

  ionViewDidEnter() {
    this.storage.getItem("token").then((res: any) => {
      this.pedidosService.getPedidosByRepartidor(res.user.id).subscribe((res: any) => {
        console.log(res);
        this.pedidos = res.data

        if(this.pedidos.length < 1){
          this.loandingPage = true;
        }else{
          this.loandingPage = false;
        }
      })
    })
  }
  sendPushIniciarEnvio(id_pedido) {
    this.pedidosService.updateEstadoPedido(id_pedido, "Listo", "Orden Lista", "Su orden esta lista").subscribe((res: any) => {
      console.log(res);
      this.pedidosService.updateEstadoPedido(
        id_pedido,
        "En camino",
        "Orden en camino",
        "El repartidor se encuentra en camino a su domicilio" // este metodo envia la push y se va a ubicar en el mapa 
      ).subscribe((res: any) => {
        console.log(res);
        this.ionViewDidEnter()
        this.presentAlert("Atención", "Orden en camino", "Debe dirigirse hacia el domicilio del cliente")
      })
    })

    this.router.navigate(["map", { id_pedido }])
  }

  goToMap(id_pedido){
    this.router.navigate(["map", { id_pedido }])
  }
  
  async presentAlert(header, subHeader, message) {
    const alert = await this.alertController.create({

      header: header,
      subHeader: subHeader,
      message: message,
      buttons: ['OK']
    });

    await alert.present();
  }

  sendPushFinalizarEntrega(id_pedido) {
    this.pedidosService.updateEstadoPedido(
      id_pedido,
      "Completado",
      "Orden completada",
      "Su orden ha sido completada, hasta pronto !!! "
    ).subscribe((res: any) => {
      console.log(res);

      this.presentAlert("Atención", "Orden Completada", "El pedido ha sido completado")
    })
  }
}
