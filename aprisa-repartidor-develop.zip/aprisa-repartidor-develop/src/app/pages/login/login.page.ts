import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { NavController, LoadingController, AlertController, MenuController } from '@ionic/angular';
import { AlertService } from 'src/app/services/alert.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  loading:any
  constructor(
    private authService: AuthService,
    private navCtrl: NavController,
    private alertService: AlertService,
    private loadingCtrl: LoadingController,
    private router: Router,
    private alertController: AlertController,
    private menuController: MenuController
  ) {
   
   }

  ngOnInit() {
    this.menuController.enable(false)
  }
  ionViewWillEnter() {
    this.authService.getToken().then(() => {
      if (this.authService.isLoggedIn) {
        this.navCtrl.navigateRoot('/pedidos-list');
      }
    });
  }

  async login(form: NgForm) {
    console.log("saltando login");

    if (form.value.email && form.value.password) {

      this.loading = await this.loadingCtrl.create({
        message: 'Por favor espere...'
      });
      await this.loading.present();
      this.authService.login(form.value.email, form.value.password).subscribe((res: any) => {
        this.navCtrl.navigateRoot(["pedidos-list"])
        this.loading.dismiss()
      }, error => {
        console.log(error);
        if (error.status == 401) {
          console.log("no autorizado");
          this.presentAlert("Atención", "Intento de inicio de sesión", "Usuario no autorizado")
          this.loading.dismiss()
        }
  
      })
    } else {
      this.alertService.presentToast("Por favor llene los campos");
    }
  }

  async presentAlert(header, subHeader, message) {
    const alert = await this.alertController.create({

      header: header,
      subHeader: subHeader,
      message: message,
      buttons: ['OK']
    });

    await alert.present();
  }

}
