import { Router } from '@angular/router';
import { HorarioService } from './../../services/horario.service';
import { AlertController, LoadingController } from '@ionic/angular';
import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-horarios-list',
  templateUrl: './horarios-list.page.html',
  styleUrls: ['./horarios-list.page.scss'],
})
export class HorariosListPage implements OnInit {

  loading: any
  horarios = []
  id_usuario
  constructor(
    private nativeStorage: NativeStorage,
    private loadingCtrl: LoadingController,
    private horarioService: HorarioService,
    private router: Router,
    private alertController: AlertController

  ) { }

  ngOnInit() {

  }

  ionViewWillEnter() {
    this.getHorarios()
  }

  async getHorarios() {
    this.loading = await this.loadingCtrl.create({
      message: 'Por favor espere...'
    });
    await this.loading.present();
    this.nativeStorage.getItem('token').then(res => {


      this.id_usuario = res.user.id
      this.horarioService.getAllByusuario(this.id_usuario).subscribe((resp: any) => {
        console.log(resp);
        this.horarios = resp.data
        this.loading.dismiss()
      }, error => {
        this.loading.dismiss()
      })

    }, error => {
      this.loading.dismiss()
    })
  }

  
  async deleteHorario(id_horario) {
    const alert = await this.alertController.create({
      cssClass: "my-custom-class",
      header: "Confirmación!",
      message: "¿Está seguro de <b>elimar</b> este horario?",
      buttons: [
        {
          text: "Cancelar",
          role: "cancel",
          cssClass: "secondary",
          handler: (blah) => {},
        },
        {
          text: "Aceptar",
          handler: () => {
            this.horarioService.delete(id_horario).subscribe((res) => {
              this.getHorarios()
            });
          },
        },
      ],
    });

    await alert.present();
  }

  goToCreateHorario() {

    let id_usuario = this.id_usuario
    this.router.navigate(["horarios-create", { id_usuario }])

  }

  goToEditHorario(horario) {
    let id_usuario = this.id_usuario
    let id_horario_repartidor = horario.id_horario_repartidor
    this.router.navigate(["horarios-edit", { id_usuario, id_horario_repartidor }])
  }
}
