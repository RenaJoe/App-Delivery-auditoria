<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_calificacion
 * @property int $id_negocio
 * @property int $id_usuario
 * @property string $calificacion
 * @property string $descripcion
 * @property int $valor
 * @property string $fecha
 * @property string $created_at
 * @property string $updated_at
 * @property Negocio $negocio
 * @property User $user
 */
class Calificacion extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'calificaciones';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_calificacion';

    /**
     * @var array
     */
    protected $fillable = ['id_negocio', 'id_usuario', 'calificacion', 'descripcion', 'valor', 'fecha', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function negocio()
    {
        return $this->belongsTo('App\Negocio', 'id_negocio', 'id_negocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_usuario');
    }
}
