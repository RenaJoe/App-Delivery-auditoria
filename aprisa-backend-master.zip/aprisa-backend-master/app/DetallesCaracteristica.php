<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_detalle_caracterisitca
 * @property int $id_caracteristica
 * @property int $id_detalle
 * @property string $created_at
 * @property string $updated_at
 * @property Detalle $detalle
 * @property Caracteristica $caracteristica
 */
class DetallesCaracteristica extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_detalle_caracterisitca';

    /**
     * @var array
     */
    protected $fillable = ['id_caracteristica', 'id_detalle', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function detalle()
    {
        return $this->belongsTo('App\Detalle', 'id_detalle', 'id_detalle');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function caracteristica()
    {
        return $this->belongsTo('App\Caracteristica', 'id_caracteristica', 'id_caracteristica');
    }
}
