<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PaymentsKushkiController extends Controller
{
    public function addPaymentCard(Request $request)
    {

        $fields = array(
            'token' => $request->token,
            'planName' => "Aprisa",
            'periodicity' => "custom",
            'contactDetails' => array(
                "email" => $request->email,
                "firstName" => $request->name,
                "lastName" => $request->lastname,
                "phoneNumber" => $request->phone,
            ),
            "amount" => array(
                "subtotalIva" => 0,
                "subtotalIva0" => 0,
                "ice" => 0,
                "iva" => 0,
                "currency" => "USD",
            ),
            "startDate" => "2025-09-25",
        );
        $fields = json_encode($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api-uat.kushkipagos.com/subscriptions/v1/card');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Private-Merchant-Id: 019f322b6de54868a7d96b99f388a921'
        ));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);

        return response()->json(["data" => json_decode($response),

            "message" => "data from api kushki"], 200);
    }
}
