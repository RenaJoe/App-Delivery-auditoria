<?php

namespace App\Http\Controllers;

use App\Calificacion;
use App\Negocio;
use Illuminate\Http\Request;

class CalificacionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $calificaciones = Calificacion::all();
        return response()->json([
            "data" => $calificaciones,
            "message" => "Succesfully Retrieved Calificaciones"
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $suma = 0;
        $promedio = 0;

        $calificacion = new Calificacion();
        $calificacion->id_negocio = $request->id_negocio;
        $calificacion->id_usuario = $request->id_usuario;
        $calificacion->calificacion = $request->calificacion;
        $calificacion->descripcion = $request->descripcion;
        $calificacion->valor = $request->valor;
        $calificacion->fecha = $request->fecha;
        $calificacion->save();

        $calificaciones = Calificacion::all()->where("id_negocio", "=", $calificacion->id_negocio);
        foreach ($calificaciones as $item) {
            $suma = $suma + $item->valor;
        }
        $promedio = $suma / $calificaciones->count();

        $negocio = Negocio::all()->find($calificacion->id_negocio);
        $negocio->calificacion_promedio = $promedio;
        $negocio->save();

        return response()->json([
            "data" => $calificacion,
            "message" => "Succesfully Created Calificacion and updated calificacion negocio"
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $calificacion = Calificacion::all()->find($id);
        return response()->json([
            "data" => $calificacion,
            "message" => "Succesfully Retrieved Calificacion By Id"
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $calificacion = Calificacion::all()->find($id);
        $calificacion->id_negocio = $request->id_negocio;
        $calificacion->id_usuario = $request->id_usuario;
        $calificacion->calificacion = $request->calificacion;
        $calificacion->descripcion = $request->descripcion;
        $calificacion->valor = $request->valor;
        $calificacion->fecha = $request->fecha;
        $calificacion->save();
        return response()->json([
            "data" => $calificacion,
            "message" => "Succesfully Updated Calificacion"
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $calificacion = Calificacion::all()->find($id);
        $calificacion->delete();
        return response()->json([
            "data" => $calificacion,
            "message" => "Succesfully Updated Calificacion"
        ], 200);
    }
}
