<?php

namespace App\Http\Controllers;

use App\Geolocalizacion;
use Illuminate\Http\Request;

class GeolocalizacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $geolocalizaciones = Geolocalizacion::all();
        return response()->json([
            "data" => $geolocalizaciones,
            "message" => "Successfully Retrieved Geolocalizaciones",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $geolocalizacion = Geolocalizacion::updateOrCreate(
            ['id_pedido' => $request->id_pedido],
            [
                'latitud' => $request->latitud,
                'longitud'=> $request->longitud,
                'estado'=> $request->estado
            ]
        );
        // $geolocalizacion->id_pedido = $request->id_pedido;
        // $geolocalizacion->latitud = $request->latitud;
        // $geolocalizacion->longitud = $request->longitud;
        // $geolocalizacion->estado = $request->estado;
        $geolocalizacion->save();
        return response()->json([
            "data" => $geolocalizacion,
            "message" => "Successfully Created or updated Geolocalizaciones",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $geolocalizacion = Geolocalizacion::all()->find($id);
        return response()->json([
            "data" => $geolocalizacion,
            "message" => "Successfully Retrieved Geolocalizacion By Id",
            "status" => 200
        ], 200);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByPedido($id)
    {
        $geolocalizacion = Geolocalizacion::where('id_pedido','=',$id)->first();
        return response()->json([
            "data" => $geolocalizacion,
            "message" => "Successfully Retrieved Geolocalizacion By Pedido",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $geolocalizacion = Geolocalizacion::all()->find($id);
        $geolocalizacion->id_pedido = $request->id_pedido;
        $geolocalizacion->latitud = $request->latitud;
        $geolocalizacion->longitud = $request->longitud;
        $geolocalizacion->estado = $request->estado;
        $geolocalizacion->save();
        return response()->json([
            "data" => $geolocalizacion,
            "message" => "Successfully Updated Geolocalizacion",
            "status" => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $geolocalizacion = Geolocalizacion::all()->find($id);
        $geolocalizacion->delete();
        return response()->json([
            "data" => $geolocalizacion,
            "message" => "Successfully Retrieved Geolocalizaciones",
            "status" => 200
        ], 200);
    }
}
