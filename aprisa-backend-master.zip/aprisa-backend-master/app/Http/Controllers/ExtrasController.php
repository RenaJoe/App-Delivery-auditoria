<?php

namespace App\Http\Controllers;

use App\Extra;
use Illuminate\Http\Request;

class ExtrasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $extras = Extra::all();
        return response()->json([
            "data" => $extras,
            "message" => "Succesfully Retrieved Extras"
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $extra = new Extra();
        $extra->id_producto = $request->id_producto;
        $extra->nombre = $request->nombre;
        $extra->foto = $request->foto;
        $extra->valor = $request->valor;
        $extra->save();
        return response()->json([
            "data" => $extra,
            "message" => "Succesfully Created Extra"
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByIdProducto($id)
    {
        $extra = Extra::where("id_producto", "=", $id)->orderBy("id_extra", "desc")->get();
        return response()->json([
            "data" => $extra,
            "message" => "Succesfully Retrieved Extra by Producto"
        ]);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $extra = Extra::all()->find($id);
        return response()->json([
            "data" => $extra,
            "message" => "Succesfully Retrieved Extra by Id"
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $extra = Extra::all()->find($id);
        $extra->id_producto = $request->id_producto;
        $extra->nombre = $request->nombre;
        $extra->foto = $request->foto;
        $extra->valor = $request->valor;
        $extra->save();
        return response()->json([
            "data" => $extra,
            "message" => "Succesfully Updated Extra"
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $extra = Extra::all()->find($id);
        $extra->delete();
        return response()->json([
            "data" => $extra,
            "message" => "Succesfully Deleted Extra"
        ], 200);
    }
}
