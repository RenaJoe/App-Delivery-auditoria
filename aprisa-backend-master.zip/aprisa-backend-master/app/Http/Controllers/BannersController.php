<?php

namespace App\Http\Controllers;

use App\Banner;
use Illuminate\Http\Request;

class BannersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $banners = Banner::all();
        return response()->json([
            "data" => $banners,
            "message" => "Successfully Retrieved Banners"
        ], 200);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function showWithNegocioAndProducto()
    {
        $banners = Banner::with("negocio", 'producto')->get();
        return response()->json([
            "data" => $banners,
            "message" => "Successfully Retrieved Banners"
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $banner = new Banner();
        $banner->id_producto = $request->id_producto;
        $banner->id_negocio = $request->id_negocio;
        $banner->foto = $request->foto;
        $banner->redireccion = $request->redireccion;
        $banner->save();
        return response()->json([
            "data" => $banner,
            "message" => "Succesfully Created Banner"
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $banner = Banner::all()->find($id);
        return response()->json([
            "data" => $banner,
            "message" => "Succesfully Retrieved banner by id",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        $banner = Banner::all()->find($id);
        $banner->id_producto = $request->id_producto;
        $banner->id_negocio = $request->id_negocio;
        $banner->foto = $request->foto;
        $banner->redireccion = $request->redireccion;
//        $banner->estado = $request->estado;
        $banner->save();
        return response()->json([
            "data" => $banner,
            "message" => "Succesfully Update Banner"
        ], 201);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        $banner = Banner::all()->find($id);
        $banner->delete();
        return response()->json([
            "data" => $banner,
            "message" => "Succesfully Deleted Banner"
        ], 201);
    }
}
