<?php

namespace App\Http\Controllers\Auth;

use App\DatosAdicionales;
use App\Direccion;
use App\Facturacion;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Rol;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            //'remember_me' => 'boolean'
        ]);
        $credentials = request(['email', 'password']);
        if (!Auth::attempt($credentials))
            return response()->json([
                'message' => 'Unauthorized'
            ], 401);
        $user = $request->user();
        $rol = Rol::all()->find($user->id_rol);
        $direccion = Direccion::where("id_usuario", "=", $user->id)->first();
        $facturacion = Facturacion::where("id_usuario", "=", $user->id)->first();
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(10);
        $token->save();
        return response()->json([
            'user' => $user,
            'rol' => $rol,
            'direccion' => $direccion,
            'facturacion' => $facturacion,
            'access_token' => $tokenResult->accessToken,
            'token_type' => 'Bearer',
            'expires_at' => Carbon::parse(
                $tokenResult->token->expires_at
            )->toDateTimeString()
        ]);
    }
    public function loginRepartidor(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            //'remember_me' => 'boolean'
        ]);
        $credentials = request(['email', 'password']);
        if (!Auth::attempt($credentials))
            return response()->json([
                'message' => 'Unauthorized'
            ], 401);
        $user = $request->user();
        $rol = Rol::all()->find($user->id_rol);
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(10);
        $token->save();
        if ($user->estado == "aprobado" && $rol->nombre == "repartidor") {
            return response()->json([
                'user' => $user,
                'rol' => $rol,
                'access_token' => $tokenResult->accessToken,
                'token_type' => 'Bearer',
                'expires_at' => Carbon::parse(
                    $tokenResult->token->expires_at
                )->toDateTimeString()
                ], 200);
        } else if ($user->estado == "pendiente") {
            return response()->json([
                'message' => 'No autorizado pendiente',
                'status' => 'Pendiente'
            ], 401);
        } else {
            return response()->json([
                'message' => 'No autorizado rechazado',
                'status' => 'Rechazado'
            ], 401);
        }
    }
    public function register(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string',
            'apellido' => 'required|string',
            // 'cedula' => 'required|string',
            // 'telefono' => 'required|string',
            // 'direccion' => 'required|string',
            'email' => 'required|string|email|unique:users',
            'password' => 'required|string'
        ]);

        $role = Rol::all()->find(1);

        $user = new User;
        $user->id_rol = $role->id_rol;
        $user->nombre = $request->nombre;
        $user->apellido = $request->apellido;
        $user->cedula = $request->cedula;
        $user->telefono = $request->telefono;
        $user->foto = $request->foto;
        $user->email = $request->email;
        $user->id_device = $request->id_device;
        $user->estado = "aprobado";
        $user->password = bcrypt($request->password);
        $user->save();
        return response()->json([
            'user' => $user,
            'message' => 'Successfully created user!'
        ], 201);
    }
    public function registerRepartidor(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string',
            'apellido' => 'required|string',
            'cedula' => 'required|string',
            'telefono' => 'required|string',
            'direccion' => 'required|string',
            'email' => 'required|string|email|unique:users',
            'password' => 'required|string'
        ]);
        $user = new User;
        $user->id_rol = 3;
        $user->nombre = $request->nombre;
        $user->apellido = $request->apellido;
        $user->cedula = $request->cedula;
        $user->telefono = $request->telefono;
        $user->email = $request->email;
        $user->estado = "pendiente";
        $user->password = bcrypt($request->password);
        $user->save();

        $datos_adicionales = new DatosAdicionales();
        $datos_adicionales->id_usuario = $user->id;
        $datos_adicionales->ciudad = $request->ciudad;
        $datos_adicionales->fecha_nacimiento = $request->fecha_nacimiento;
        $datos_adicionales->tipo_vehiculo = $request->tipo_vehiculo;
        $datos_adicionales->foto_cedula = $request->foto_cedula;
        $datos_adicionales->save();

        return response()->json([
            'user' => $user,
            'additional data' => $datos_adicionales,
            'message' => 'Successfully created user!'
        ], 201);
    }
    public function logout(Request $request)
    {
        $request->user()->token()->revoke();
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }

    public function loginSuperAdmin(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
            //'remember_me' => 'boolean'
        ]);
        $credentials = request(['email', 'password']);
        if (!Auth::attempt($credentials))
            return response()->json([
                'message' => 'Unauthorized'
            ], 401);
        $user = $request->user();
        $rol = Rol::all()->find($user->id_rol);
        $tokenResult = $user->createToken('Personal Access Token');
        $token = $tokenResult->token;
        if ($request->remember_me)
            $token->expires_at = Carbon::now()->addWeeks(10);
        $token->save();
        if ($user->estado == "aprobado" && $rol->id_rol == 4) {
            return response()->json([
                'user' => $user,
                'rol' => $rol,
                'access_token' => $tokenResult->accessToken,
                'token_type' => 'Bearer',
                'expires_at' => Carbon::parse(
                    $tokenResult->token->expires_at
                )->toDateTimeString()
            ], 200);
        } else if ($user->estado == "pendiente") {
            return response()->json([
                'message' => 'No autorizado pendiente',
                'status' => 'Pendiente'
            ], 401);
        } else {
            return response()->json([
                'message' => 'No autorizado rechazado',
                'status' => 'Rechazado'
            ], 401);
        }
    }

    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function user(Request $request)
    {
        return response()->json($request->user());
    }

    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function allUsers()
    {
        $users = User::where('id_rol','1')->orderBy('id', 'desc')->get();
        return response()->json([
            "data" => $users,
            "message" => "Succesfully Retrived Users",
            "status" => "200"
        ], 200);
    }

    public function allRepartidores()
    {
        $users = User::where('id_rol','3')->orderBy('id', 'desc')->get();
        return response()->json([
            "data" => $users,
            "message" => "Succesfully Retrived Repartidores",
            "status" => "200"
        ], 200);
    }

    public function updateRepartidor($id,Request $request){
        $user = User::all()->find($id);
        $user->nombre = $request->nombre;
        $user->apellido = $request->apellido;
        $user->cedula = $request->cedula;
        $user->email = $request->email;
        $user->telefono = $request->telefono;
        $user->foto = $request->foto;
        $user->save();
    }

    public function updateUser($id, Request $request)
    {
        $user = User::all()->find($id);
        $user->cedula = $request->cedula;
        $user->telefono = $request->telefono;
        $user->foto = $request->foto;
        $user->save();

        return response()->json([
            "data" => $user,
            "message" => "Succesfully Updated User",
            "status" => "200"
        ], 200);
    }

    /**
     * Get the authenticated User
     *
     * @return [json] user object
     */
    public function updateEstadoUser($id, Request $request)
    {
        $user = User::all()->find($id);

        $user->estado = $request->estado;
        $user->save();

        return response()->json([
            "data" => $user,
            "message" => "Succesfully Updated Estado User",
            "status" => "200"
        ], 200);
    }
}
