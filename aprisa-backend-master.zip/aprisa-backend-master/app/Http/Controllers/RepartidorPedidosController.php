<?php

namespace App\Http\Controllers;

use App\Pedido;
use App\RepartidorPedido;
use Illuminate\Http\Request;

class RepartidorPedidosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $repartidorPedidos = RepartidorPedido::all()->where("id_pedido", "=", $request->id_pedido);
        if ($repartidorPedidos->count() == 0) {
            $repartidorPedido = new RepartidorPedido();
            $repartidorPedido->id_usuario = $request->id_usuario;
            $repartidorPedido->id_pedido = $request->id_pedido;
            $repartidorPedido->save();

            $pedido = Pedido::all()->find($request->id_pedido);
            $pedido->estado = "Preparando";
            $pedido->save();
            $this->SendPush($pedido->id_device); //here send the push notif
            return response()->json([
                "data" => $repartidorPedido,
                "message" => "Succesfully Created Repartidor Pedido",
                "status" => 200
            ], 200);
        } else {
            return response()->json([

                "message" => "Pedido already register",
                "status" => 401
            ], 401);
        }
    }

    public function SendPush($id_device)
    {


        $contents = array(
            "en" => 'Your Order is being prepared ',
            "es" => 'Su orden esta siendo preparada'
        );
        $headings = array(
            "en" => "Getting ready",
            "es" => "Preparando Orden"
        );
        $fields = array(
            'app_id' => "03f3c1bd-3e17-4ef5-bc59-55b580185384",
            'include_player_ids' => array($id_device),
            'contents' => $contents,
            'headings' => $headings
        );
        $fields = json_encode($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic OWYyMjVhNmMtYWY1YS00MGUyLWIyZmUtZTg3ODY5ZmM1ODJl'
        ));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);


        return $response;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $repartidorPedidos = RepartidorPedido::with("pedido")->where("id_usuario", "=", $id)->orderBy('id_pedido', 'desc')->get();
        $pedidos = Pedido::with('user', 'negocio', 'direccion', 'facturacion')->orderBy('id_pedido', 'desc')->get();

        foreach ($repartidorPedidos as $repartidorPedido) {
            foreach ($pedidos as $pedido) {

                if ($repartidorPedido->id_pedido == $pedido->id_pedido) {
                    $repartidorPedido->pedido->user = $pedido->user;
                    $repartidorPedido->pedido->negocio = $pedido->negocio;
                    $repartidorPedido->pedido->facturacion = $pedido->facturacion;
                    $repartidorPedido->pedido->direccion = $pedido->direccion;
                }
            }
        }

        return response()->json([
            "data" => $repartidorPedidos,
            "message" => "Succesfully Retrieved repartidorPedido By User",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
