<?php

namespace App\Http\Controllers;

use App\Caracteristica;
use App\Detalle;
use App\DetallesCaracteristica;
use App\DetallesExtra;
use App\Extra;
use Illuminate\Http\Request;

class DetallesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $detalles = Detalle::all();
        return response()->json([
            "data" => $detalles,
            "message" => "Succesfully Retrieved Detalles",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $detalle = new Detalle();
        $detalle->id_producto = $request->id_producto;
        $detalle->id_pedido = $request->id_pedido;
        $detalle->cantidad = $request->cantidad;
        $detalle->total = $request->total;
        $detalle->save();
        return response()->json([
            "data" => $detalle,
            "message" => "Succesfully Created Detalle",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $detalle = Detalle::all()->find($id);
        return response()->json([
            "data" => $detalle,
            "message" => "Succesfully Retrieved Detalles By Id",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showDetallesByPedido($id)
    {
        $detalles = Detalle::with("producto", "detallesExtras.extra", "detallesCaracteristicas.caracteristica")->where("id_pedido", "=", $id)->get();

        return response()->json([
            "data" => $detalles,
            "message" => "Succesfully Retrieved Detalles By Id Pedido Tesst",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $detalle = Detalle::all()->find($id);
        $detalle->id_producto = $request->id_producto;
        $detalle->id_pedido = $request->id_pedido;
        $detalle->cantidad = $request->cantidad;
        $detalle->total = $request->total;
        $detalle->save();
        return response()->json([
            "data" => $detalle,
            "message" => "Succesfully Updated Detalles",
            "status" => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $detalle = Detalle::all()->find($id);
        $detalle->delete();
        return response()->json([
            "data" => $detalle,
            "message" => "Succesfully Deleted Detalles",
            "status" => 200
        ], 200);
    }
}
