<?php

namespace App\Http\Controllers;

use App\Producto;
use Illuminate\Http\Request;

class ProductosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $productos = Producto::with("categoria.negocio")->get();
        return response()->json([
            "data" => $productos,
            "message" => "Succesfully Retrieved Productos",
            "status" => 200
        ], 200);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function showProductosOferta()
    {
        $productos = Producto::with("categoria")->where('oferta', '=', true)->get();
        return response()->json([
            "data" => $productos,
            "message" => "Succesfully Retrieved Productos",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $producto = new Producto();
        $producto->id_categoria = $request->id_categoria;
        $producto->nombre = $request->nombre;
        $producto->descripcion = $request->descripcion;
        $producto->precio = $request->precio;
        $producto->precio_oferta = $request->precio_oferta;
        $producto->oferta = $request->oferta;
        $producto->limitante = $request->limitante;
        $producto->foto = $request->foto;
        $producto->tipo_foto = $request->tipo_foto;
        $producto->estado = $request->estado;
        $producto->save();

        return response()->json([
            "data" => $producto,
            "message" => "Succesfully Created Producto",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $producto = Producto::with('extras', 'caracteristicas','categoria.negocio')->find($id);
        return response()->json([
            "data" => $producto,
            "message" => "Succesfully retrieved Producto By Id",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByNombre($nombre)
    {
        $productos = Producto::with("categoria")->where("nombre", "ilike", '%' . $nombre . '%')->orderBy('id_producto', 'desc')->get();
        return response()->json([
            "data" => $productos,
            "message" => "Succesfully Retrived Productos By Nombre",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $producto = Producto::all()->find($id);
        $producto->id_categoria = $request->id_categoria;
        $producto->nombre = $request->nombre;
        $producto->descripcion = $request->descripcion;
        $producto->precio = $request->precio;
        $producto->precio_oferta = $request->precio_oferta;
        $producto->oferta = $request->oferta;
        $producto->foto = $request->foto;
        $producto->limitante = $request->limitante;
        $producto->tipo_foto = $request->tipo_foto;
        $producto->estado = $request->estado;
        $producto->save();
        return response()->json([
            "data" => $producto,
            "message" => "Succesfully Updated Producto",
            "status" => 200
        ], 200);
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateOferta(Request $request, $id)
    {
        $producto = Producto::all()->find($id);
        $producto->oferta = $request->oferta;
        $producto->save();
        return response()->json([
            "data" => $producto,
            "message" => "Succesfully Updated Oferta Producto",
            "status" => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $producto = Producto::all()->find($id);
        $producto->delete();
        return response()->json([
            "data" => $producto,
            "message" => "Succesfully Deleted Producto",
            "status" => 200
        ], 200);
    }
}
