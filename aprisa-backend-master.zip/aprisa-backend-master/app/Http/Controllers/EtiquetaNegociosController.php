<?php

namespace App\Http\Controllers;

use App\Etiqueta;
use App\EtiquetaNegocio;
use Illuminate\Http\Request;

class EtiquetaNegociosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $etitquetaNegocio = new EtiquetaNegocio();
        $etitquetaNegocio->id_etiqueta = $request->id_etiqueta;
        $etitquetaNegocio->id_negocio = $request->id_negocio;
        $etitquetaNegocio->save();
        return response()->json([
            "data" => $etitquetaNegocio,
            "message" => "Succesfully Created etiquetaNegocio"
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $etitquetasNegocio = EtiquetaNegocio::with('etiqueta')->where('id_negocio', '=', $id)->get();
        return response()->json([
            "data" => $etitquetasNegocio,
            "message" => "Succesfully Retrieved Etiquetas by Negocio"
        ], 200);
    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $etitquetaNegocio = EtiquetaNegocio::all()->find($id);
        $etitquetaNegocio->delete();
        return response()->json([
            "data" => $etitquetaNegocio,
            "message" => "Succesfully Deleted etiquetaNegocio"
        ], 200);
    }
}
