<?php

namespace App\Http\Controllers;

use App\Horario;
use Illuminate\Http\Request;

class HorariosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        $horarios = Horario::all();
        return response()->json([
            "data" => $horarios,
            "message" => "Succesfully Retrieved Horarios",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $horario = new Horario();
        $horario->id_negocio = $request->id_negocio;
        $horario->dia = $request->dia;
        $horario->inicio = $request->inicio;
        $horario->fin = $request->fin;

        $checkHorario = $this->existeHorario($horario->id_negocio, $horario->dia);
        if ($checkHorario != null) {
            return response()->json([
                "data" => $checkHorario,
                "message" => "Horario ya existente",
                "status" => 200
            ], 409);
        }

        $horario->save();
        return response()->json([
            "data" => $horario,
            "message" => "Succesfully Created Horario",
            "status" => 200
        ], 200);
    }

    public function existeHorario($id_negocio, $dia)
    {
        $horario = Horario::where('id_negocio', $id_negocio)->where('dia', $dia)->first();
        return $horario;
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $horario = Horario::all()->find($id);
        return response()->json([
            "data" => $horario,
            "message" => "Succesfully Retrieved Horario By Id",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id_negocio
     * @return \Illuminate\Http\JsonResponse
     */
    public function horariosByNegocioId($id_negocio)
    {
        $horarios = Horario::where('id_negocio', $id_negocio)->orderBy('id_horario','ASC')->get();
        return response()->json([
            "data" => $horarios,
            "message" => "Succesfully Retrieved Horario By  Negocio Id",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        $horario = Horario::all()->find($id);
        $horario->id_negocio = $request->id_negocio;
        $horario->dia = $request->dia;
        $horario->inicio = $request->inicio;
        $horario->fin = $request->fin;

        $checkHorario = $this->existeHorario($horario->id_negocio, $horario->dia);
        if ($checkHorario != null) {
            if ($checkHorario->id_horario != $horario->id_horario) {
                return response()->json([
                    "data" => $checkHorario,
                    "message" => "Horario ya existente",
                    "status" => 200
                ], 409);
            }
        }
        $horario->save();
        return response()->json([
            "data" => $horario,
            "message" => "Succesfully Updated Horario",
            "status" => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        $horario = Horario::all()->find($id);
        $horario->delete();
        return response()->json([
            "data" => $horario,
            "message" => "Succesfully Deleted Horario",
            "status" => 200
        ], 200);
    }
}
