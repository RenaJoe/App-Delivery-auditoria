<?php

namespace App\Http\Controllers;

use App\Direccion;
use Illuminate\Http\Request;

class DireccionesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $direccion = new Direccion();
        $direccion->id_usuario = $request->id_usuario;
        $direccion->latitud = $request->latitud;
        $direccion->longitud = $request->longitud;
        $direccion->ciudad = $request->ciudad;
        $direccion->calle = $request->calle;
        $direccion->nro = $request->nro;
        $direccion->piso = $request->piso;
        $direccion->departamento = $request->departamento;
        $direccion->referencia = $request->referencia;
        $direccion->save();
        return response()->json([
            "data" => $direccion,
            "message" => "Succesfully Created Direccion"
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $direccion = Direccion::all()->find($id);
        return response()->json([
            "data" => $direccion,
            "message" => "Succesfully Retrieved Direccion"
        ], 200);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByIdUser($id)
    {
        $direccion = Direccion::where("id_usuario", "=", $id)->orderBy('id_direccion', 'asc')->get();
        return response()->json([
            "data" => $direccion,
            "message" => "Succesfully Retrieved Direcciones By User"
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $direccion = Direccion::all()->find($id);
        $direccion->id_usuario = $request->id_usuario;
        $direccion->latitud = $request->latitud;
        $direccion->longitud = $request->longitud;
        $direccion->ciudad = $request->ciudad;
        $direccion->calle = $request->calle;
        $direccion->nro = $request->nro;
        $direccion->piso = $request->piso;
        $direccion->departamento = $request->departamento;
        $direccion->referencia = $request->referencia;
        $direccion->save();
        return response()->json([
            "data" => $direccion,
            "message" => "Succesfully Updated Direccion"
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
