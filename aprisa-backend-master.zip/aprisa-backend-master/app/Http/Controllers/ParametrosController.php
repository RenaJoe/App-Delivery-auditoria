<?php

namespace App\Http\Controllers;

use App\Parametro;
use Illuminate\Http\Request;

class ParametrosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parametros = Parametro::orderBy('id_parametro', 'asc')->get();
        return response()->json([
            "data" => $parametros,
            "message" => "Succesfully retrieved all parametros",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $parametro = new Parametro();
        $parametro->nombre = $request->nombre;
        $parametro->valor = $request->valor;
        $parametro->save();
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully Created parametro",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $parametro = Parametro::all()->find($id);
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully Created parametro",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showVersionClient()
    {
        $parametro = Parametro::all()->find(3);
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully retrieved version",
            "status" => 200
        ], 200);
    }

    public function updateVersionClient(Request $request)
    {
        $parametro = Parametro::all()->find(3);
        $parametro->valor = $request->valor;
        $parametro->save();
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully Updated Version Cliente",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showVersionVendor()
    {
        $parametro = Parametro::all()->find(4);
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully retrieved version",
            "status" => 200
        ], 200);
    }
    public function updateVersionVendor(Request $request)
    {
        $parametro = Parametro::all()->find(4);
        $parametro->valor = $request->valor;
        $parametro->save();
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully Updated Version Cliente",
            "status" => 200
        ], 200);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showVersionRepartidor()
    {
        $parametro = Parametro::all()->find(5);
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully retrieved version",
            "status" => 200
        ], 200);
    }
    public function updateVersionRepartidor(Request $request)
    {
        $parametro = Parametro::all()->find(5);
        $parametro->valor = $request->valor;
        $parametro->save();
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully Updated Version Cliente",
            "status" => 200
        ], 200);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $parametro = Parametro::all()->find($id);
        $parametro->nombre = $request->nombre;
        $parametro->valor = $request->valor;
        $parametro->save();
        return response()->json([
            "data" => $parametro,
            "message" => "Succesfully Created parametro",
            "status" => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
