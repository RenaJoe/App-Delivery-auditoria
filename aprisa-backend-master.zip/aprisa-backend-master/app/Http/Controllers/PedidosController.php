<?php

namespace App\Http\Controllers;

use App\Negocio;
use App\Pedido;
use Illuminate\Http\Request;

class PedidosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pedidos = Pedido::with("user", "negocio")->orderBy('id_pedido', 'desc')->get();
        return response()->json([
            "data" => $pedidos,
            "message" => "Succesfully Retrieved Pedidos",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $pedido = new Pedido();
        $pedido->id_usuario = $request->id_user;
        $pedido->id_negocio = $request->id_negocio;
        $pedido->id_direccion = $request->id_direccion;
        $pedido->id_facturacion = $request->id_facturacion;
        $pedido->subtotal = $request->subtotal;
        $pedido->costo_envio = $request->costo_envio;
        $pedido->total = $request->total;
        $pedido->observaciones = $request->observaciones;
        $pedido->tipo_pago = $request->tipo_pago;
        $pedido->id_device = $request->id_device;
        $pedido->estado = $request->estado;
        $pedido->save();
        return response()->json([
            "data" => $pedido,
            "message" => "Succesfully Created Pedido",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $pedido = Pedido::with("user",'direccion','negocio')->find($id);
        return response()->json([
            "data" => $pedido,
            "message" => "Succesfully Retrieved Pedidos By Id",
            "status" => 200
        ], 200);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByNegocio($id)
    {
        $negocio = Negocio::all()->where("id_usuario", "=", $id)->first();
        $pedidos = Pedido::with("user","direccion")->where("id_negocio", "=", $negocio->id_negocio)->orderBy('id_pedido', 'desc')->get();
        return response()->json([
            "data" => $pedidos,
            "message" => "Succesfully Retrieved Pedidos By Negocio",
            "status" => 200
        ], 200);
    }
    //this is a comment
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByUser($id)
    {
        $pedidos = Pedido::with("negocio", "direccion")->where("id_usuario", "=", $id)->orderBy('id_pedido', 'desc')->get();
        return response()->json([
            "data" => $pedidos,
            "message" => "Succesfully Retrieved Pedidos By User",
            "status" => 200
        ], 200);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function pedidosAndNegocio($id)
    {
        $pedido = Pedido::with("negocio", "direccion")->find($id);
        return response()->json([
            "data" => $pedido,
            "message" => "Succesfully Retrieved Pedidos By Id",
            "status" => 200
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $pedido = Pedido::all()->find($id);
        $pedido->id_usuario = $request->id_usuario;
        $pedido->id_negocio = $request->id_negocio;
        $pedido->id_direccion = $request->id_direccion;
        $pedido->id_facturacion = $request->id_facturacion;
        $pedido->subtotal = $request->subtotal;
        $pedido->costo_envio = $request->costo_envio;
        $pedido->total = $request->total;
        $pedido->observaciones = $request->observaciones;
        $pedido->tipo_pago = $request->tipo_pago;
        $pedido->id_device = $request->id_device;
        $pedido->estado = $request->estado;
        $pedido->save();
        $this->SendPush($request->id_device);
        return response()->json([
            "data" => $pedido,
            "message" => "Succesfully Updated Pedidos",
            "status" => 200
        ], 200);
    }

    public function updateEstadoPedido(Request $request, $id)
    {
        $pedido = Pedido::all()->find($id);
        $pedido->estado = $request->estado;
        $pedido->save(); // actualizar el tiempo de preparacion
        if ($pedido->estado == "Completado") {
            # code...
            $this->SendPushCompleteServicio($pedido->id_device, $request->header, $request->content, $pedido->id_negocio);
        } else {
            $this->SendPushWithMessage($pedido->id_device, $request->header, $request->content);
        }
        return response()->json([
            "data" => $pedido,
            "message" => "Succesfully Updated Pedidos with notificacion push",
            "header" => $request->header,
            "content" => $request->content,
            "status" => 200
        ], 200);
    }

    public function SendPushCompleteServicio($id_device, $header, $content, $id_negocio)
    {
        $contents = array(
            "en" => $content,
            "es" => $content
        );

        $headings = array(
            "en" => $header,
            "es" => $header
        );

        $data = array(
            "id_negocio" => $id_negocio
        );

        $fields = array(
            'app_id' => "b921b152-b3d6-4273-9caf-06ff698ad88d", // cliente
            'include_player_ids' => array($id_device),
            'data' => $data,
            'contents' => $contents,
            'headings' => $headings
        );
        $fields = json_encode($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic MmRjZTAzNjYtYjE5MC00ZGZkLThjOTAtMzNlYTE0Zjk3NTQ0' //cliente
        ));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);


        return $response;
    }

    public function SendPushWithMessage($id_device, $header, $content)
    {
        $contents = array(
            "en" => $content,
            "es" => $content
        );

        $headings = array(
            "en" => $header,
            "es" => $header
        );

        $fields = array(
            'app_id' => "b921b152-b3d6-4273-9caf-06ff698ad88d", //cliente
            'include_player_ids' => array($id_device),
            'contents' => $contents,
            'headings' => $headings
        );
        $fields = json_encode($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic MmRjZTAzNjYtYjE5MC00ZGZkLThjOTAtMzNlYTE0Zjk3NTQ0' //cliente
        ));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);


        return $response;
    }

    public function SendPush($id_device)
    {


        $contents = array(
            "en" => 'Your Order has been confirmed',
            "es" => 'Su orden ha sido confirmada'
        );
        $headings = array(
            "en" => "Order Confirmed",
            "es" => "Orden Confirmada"
        );
        $fields = array(
            'app_id' => "b921b152-b3d6-4273-9caf-06ff698ad88d", //cliente
            'include_player_ids' => array($id_device),
            'contents' => $contents,
            'headings' => $headings
        );
        $fields = json_encode($fields);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://onesignal.com/api/v1/notifications');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Authorization: Basic MmRjZTAzNjYtYjE5MC00ZGZkLThjOTAtMzNlYTE0Zjk3NTQ0' // cliente
        ));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);


        return $response;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pedido = Pedido::all()->find($id);
        $pedido->delete();
        return response()->json([
            "data" => $pedido,
            "message" => "Succesfully Deleted Pedidos",
            "status" => 200
        ], 200);
    }
}
