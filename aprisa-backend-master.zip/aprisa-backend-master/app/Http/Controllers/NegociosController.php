<?php

namespace App\Http\Controllers;

use App\Negocio;
use Illuminate\Http\Request;

class NegociosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $negocios = Negocio::orderBy('id_negocio', 'desc')->get();
        return response()->json([
            "data" => $negocios,
            "message" => "Succesfully Retrived Negocios",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $negocios = new Negocio();
        $negocios->id_usuario = $request->id_usuario;
        $negocios->id_tipo_servicio = $request->id_tipo_servicio;
        $negocios->nombre = $request->nombre;
        $negocios->codigo = $request->codigo;
        $negocios->latitud = $request->latitud;
        $negocios->longitud = $request->longitud;
        $negocios->foto = $request->foto;
        $negocios->direccion = $request->direccion;
        $negocios->telefono = $request->telefono;
        $negocios->save();

        return response()->json([
            "data" => $negocios,
            "message" => "Succesfully Created Negocio",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $negocio = Negocio::with("categorias", "horarios")->find($id);
        return response()->json([
            "data" => $negocio,
            "message" => "Succesfully Retrived Negocio By Id",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function showByNombre($nombre)
    {
        $negocios = Negocio::where("nombre", "ilike", '%' . $nombre . '%')->orderBy('id_negocio', 'desc')->get();
        return response()->json([
            "data" => $negocios,
            "message" => "Succesfully Retrived Negocios By Nombre",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function showByUserId($id)
    {
        $negocio = Negocio::with("categorias")->where("id_usuario", "=", $id)->get();
        return response()->json([
            "data" => $negocio,
            "message" => "Succesfully Retrived Negocio By Id Usuario",
            "status" => 200
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function showByCodigo($id)
    {
        $negocio = Negocio::with("categorias")->where("codigo", "=", $id)->get();
        return response()->json([
            "data" => $negocio,
            "message" => "Succesfully Retrived Negocio By Id Usuario",
            "status" => 200
        ], 200);
    }

    public function negociosByTipoServicio($id)
    {
        $negocios = Negocio::where("id_tipo_servicio", "=", $id)->orderBy('id_negocio', 'desc')->get();
        return response()->json([
            "data" => $negocios,
            "message" => "Succesfully Retrived Negocios",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $negocio = Negocio::all()->find($id);
        $negocio->id_usuario = $request->id_usuario;
        $negocio->id_tipo_servicio = $request->id_tipo_servicio;
        $negocio->nombre = $request->nombre;
        $negocio->direccion = $request->direccion;
        $negocio->codigo = $request->codigo;
        $negocio->latitud = $request->latitud;
        $negocio->longitud = $request->longitud;
        $negocio->foto = $request->foto;
        $negocio->telefono = $request->telefono;
        $negocio->save();
        return response()->json([
            "data" => $negocio,
            "message" => "Succesfully Updated Negocio",
            "status" => 200
        ], 200);
    }

    public function updateTiempoPreparacion(Request $request, $id)
    {
        $negocio = Negocio::all()->find($id);
        $negocio->tiempo_preparacion = $request->tiempo_preparacion;
        $negocio->save();
        return response()->json([
            "data" => $negocio,
            "message" => "Succesfully Updated Tiempo preparacion",
            "status" => 200
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $negocio = Negocio::all()->find($id);
        $negocio->delete();
        return response()->json([
            "data" => $negocio,
            "message" => "Succesfully Deleted Negocio",
            "status" => 200
        ], 200);
    }
}
