<?php

namespace App\Http\Controllers;

use App\Caracteristica;
use Illuminate\Http\Request;

class CaracteristicasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $caracteristicas = Caracteristica::all();
        return response()->json([
            "data" => $caracteristicas,
            "message" => "Succesfully retrieved caracteristicas",
            "status" => 200
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $caracteristica = new Caracteristica();
        $caracteristica->id_producto = $request->id_producto;
        $caracteristica->nombre = $request->nombre;
        $caracteristica->save();
        return response()->json([
            "data" => $caracteristica,
            "message" => "Succesfully Created Caracteristica"
        ], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showByIdProducto($id)
    {
        $caracteristica = Caracteristica::where("id_producto", "=", $id)->orderBy('id_caracteristica', 'desc')->get();

        return response()->json([
            "data" => $caracteristica,
            "message" => "Succesfully Retrieved Caracteristica by Producto"
        ], 200);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $caracteristica = Caracteristica::all()->find($id);

        return response()->json([
            "data" => $caracteristica,
            "message" => "Succesfully Retrieved Caracteristica by Id"
        ], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $caracteristica = Caracteristica::all()->find($id);
        $caracteristica->id_producto = $request->id_producto;
        $caracteristica->nombre = $request->nombre;
        $caracteristica->save();
        return response()->json([
            "data" => $caracteristica,
            "message" => "Succesfully Updated Caracteristica"
        ], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $caracteristica = Caracteristica::all()->find($id);
        $caracteristica->delete();
        return response()->json([
            "data" => $caracteristica,
            "message" => "Succesfully Deleted Caracteristica"
        ], 200);
    }
}
