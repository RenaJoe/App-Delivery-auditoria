<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_pedido
 * @property int $id_usuario
 * @property int $id_negocio
 * @property int $id_direccion
 * @property int $id_facturacion
 * @property float $subtotal
 * @property float $costo_envio
 * @property float $total
 * @property string $observaciones
 * @property string $tipo_pago
 * @property string $estado
 * @property string $id_device
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 * @property Negocio $negocio
 * @property Direccion $direccion
 * @property Facturacione $facturacione
 * @property Detalle[] $detalles
 * @property Geolocalizacion[] $geolocalizacions
 * @property RepartidorPedido[] $repartidorPedidos
 */
class Pedido extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_pedido';

    /**
     * @var array
     */
    protected $fillable = ['id_usuario', 'id_negocio', 'id_direccion', 'id_facturacion', 'subtotal', 'costo_envio', 'total', 'observaciones', 'tipo_pago', 'estado', 'tiempo_preparacion', 'id_device', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function negocio()
    {
        return $this->belongsTo('App\Negocio', 'id_negocio', 'id_negocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function direccion()
    {
        return $this->belongsTo('App\Direccion', 'id_direccion', 'id_direccion');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function facturacion()
    {
        return $this->belongsTo('App\Facturacion', 'id_facturacion', 'id_facturacion');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function detalles()
    {
        return $this->hasMany('App\Detalle', 'id_pedido', 'id_pedido');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function geolocalizacions()
    {
        return $this->hasMany('App\Geolocalizacion', 'id_pedido', 'id_pedido');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function repartidorPedidos()
    {
        return $this->hasMany('App\RepartidorPedido', 'id_pedido', 'id_pedido');
    }
}
