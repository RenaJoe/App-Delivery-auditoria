<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_direccion
 * @property int $id_usuario
 * @property float $latitud
 * @property float $longitud
 * @property string $ciudad
 * @property string $calle
 * @property string $nro
 * @property string $piso
 * @property string $departamento
 * @property string $referencia
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 * @property Pedido[] $pedidos
 */
class Direccion extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'direcciones';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_direccion';

    /**
     * @var array
     */
    protected $fillable = ['id_usuario', 'latitud', 'longitud', 'ciudad', 'calle', 'nro', 'piso', 'departamento', 'referencia', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pedidos()
    {
        return $this->hasMany('App\Pedido', 'id_direccion', 'id_direccion');
    }
}
