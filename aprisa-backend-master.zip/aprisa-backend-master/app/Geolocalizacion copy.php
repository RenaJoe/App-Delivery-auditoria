<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_geolocalizacion
 * @property int $id_pedido
 * @property float $latitud
 * @property float $longitud
 * @property string $estado
 * @property Pedido $pedido
 */
class Geolocalizacion extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'geolocalizacion';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_geolocalizacion';

    /**
     * @var array
     */
    protected $fillable = ['id_pedido', 'latitud', 'longitud', 'estado'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function pedido()
    {
        return $this->belongsTo('App\Pedido', 'id_pedido', 'id_pedido');
    }
}
