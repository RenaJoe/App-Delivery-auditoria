<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_administrador
 * @property string $nombre
 * @property string $email
 * @property string $password
 * @property Negocio[] $negocios
 */
class Administrador extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'administradores';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_administrador';

    /**
     * @var array
     */
    protected $fillable = ['nombre', 'email', 'password'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function negocios()
    {
        return $this->hasMany('App\Negocio', 'id_administrador', 'id_administrador');
    }
}
