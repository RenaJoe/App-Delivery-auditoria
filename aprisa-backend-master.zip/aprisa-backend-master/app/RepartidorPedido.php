<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_repartidor_pedido
 * @property int $id_usuario
 * @property int $id_pedido
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 * @property Pedido $pedido
 */
class RepartidorPedido extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_repartidor_pedido';

    /**
     * @var array
     */
    protected $fillable = ['id_usuario', 'id_pedido', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function pedido()
    {
        return $this->belongsTo('App\Pedido', 'id_pedido', 'id_pedido');
    }
}
