<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_facturacion
 * @property int $id_usuario
 * @property string $tipo_documento
 * @property string $nombre_completo
 * @property string $cedula
 * @property string $telefono
 * @property string $email
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 * @property Pedido[] $pedidos
 */
class Facturacion extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'facturaciones';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_facturacion';

    /**
     * @var array
     */
    protected $fillable = ['id_usuario', 'tipo_documento', 'nombre_completo', 'cedula', 'telefono', 'email', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pedidos()
    {
        return $this->hasMany('App\Pedido', 'id_facturacion', 'id_facturacion');
    }
}
