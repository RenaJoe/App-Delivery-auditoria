<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_horario
 * @property int $id_negocio
 * @property string $dia
 * @property float $inicio
 * @property float $fin
 * @property Negocio $negocio
 */
class Horario extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'horario';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_horario';

    /**
     * @var array
     */
    protected $fillable = ['id_negocio', 'dia', 'inicio', 'fin'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function negocio()
    {
        return $this->belongsTo('App\Negocio', 'id_negocio', 'id_negocio');
    }
}
