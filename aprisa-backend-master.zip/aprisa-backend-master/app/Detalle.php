<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_detalle
 * @property int $id_producto
 * @property int $id_pedido
 * @property int $cantidad
 * @property float $total
 * @property string $created_at
 * @property string $updated_at
 * @property Producto $producto
 * @property Pedido $pedido
 * @property DetallesExtra[] $detallesExtras
 * @property DetallesCaracteristica[] $detallesCaracteristicas
 */
class Detalle extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_detalle';

    /**
     * @var array
     */
    protected $fillable = ['id_producto', 'id_pedido', 'cantidad', 'total', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function producto()
    {
        return $this->belongsTo('App\Producto', 'id_producto', 'id_producto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function pedido()
    {
        return $this->belongsTo('App\Pedido', 'id_pedido', 'id_pedido');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function detallesExtras()
    {
        return $this->hasMany('App\DetallesExtra', 'id_detalle', 'id_detalle');
        // return $this->hasManyThrough('App\Extra', 'App\DetallesExtra', 'id_detalle', 'id_detalle', 'id_extra', 'id_extra');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function detallesCaracteristicas()
    {
        return $this->hasMany('App\DetallesCaracteristica', 'id_detalle', 'id_detalle');
    }
}
