<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_detalles_extra
 * @property int $id_extra
 * @property int $id_detalle
 * @property string $created_at
 * @property string $updated_at
 * @property Extra $extra
 * @property Detalle $detalle
 */
class DetallesExtra extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'detalles_extra';

    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_detalles_extra';

    /**
     * @var array
     */
    protected $fillable = ['id_extra', 'id_detalle', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function extra()
    {
        return $this->belongsTo('App\Extra', 'id_extra', 'id_extra');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function detalle()
    {
        return $this->belongsTo('App\Detalle', 'id_detalle', 'id_detalle');
    }
}
