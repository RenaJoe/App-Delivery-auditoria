<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_tipo_servicio
 * @property string $nombre
 * @property string $created_at
 * @property string $updated_at
 * @property Negocio[] $negocios
 */
class TiposServicio extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_tipo_servicio';

    /**
     * @var array
     */
    protected $fillable = ['nombre', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function negocios()
    {
        return $this->hasMany('App\Negocio', 'id_tipo_servicio', 'id_tipo_servicio');
    }
}
