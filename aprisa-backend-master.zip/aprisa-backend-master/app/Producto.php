<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_producto
 * @property int $id_categoria
 * @property string $nombre
 * @property string $descripcion
 * @property float $precio
 * @property float $precio_oferta
 * @property string $foto
 * @property string $tipo_foto
 * @property boolean $estado
 * @property int $limitante
 * @property boolean $oferta
 * @property string $created_at
 * @property string $updated_at
 * @property Categoria $categoria
 * @property Caracteristica[] $caracteristicas
 * @property Detalle[] $detalles
 * @property Extra[] $extras
 */
class Producto extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_producto';

    /**
     * @var array
     */
    protected $fillable = ['id_categoria', 'nombre', 'descripcion', 'precio', 'precio_oferta', 'foto', 'tipo_foto', 'estado', 'limitante', 'oferta', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function categoria()
    {
        return $this->belongsTo('App\Categoria', 'id_categoria', 'id_categoria');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function caracteristicas()
    {
        return $this->hasMany('App\Caracteristica', 'id_producto', 'id_producto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function detalles()
    {
        return $this->hasMany('App\Detalle', 'id_producto', 'id_producto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function extras()
    {
        return $this->hasMany('App\Extra', 'id_producto', 'id_producto');
    }
}
