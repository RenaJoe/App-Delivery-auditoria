<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_caracteristica
 * @property int $id_producto
 * @property string $nombre
 * @property string $created_at
 * @property string $updated_at
 * @property Producto $producto
 * @property DetallesCaracteristica[] $detallesCaracteristicas
 */
class Caracteristica extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_caracteristica';

    /**
     * @var array
     */
    protected $fillable = ['id_producto', 'nombre', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function producto()
    {
        return $this->belongsTo('App\Producto', 'id_producto', 'id_producto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function detallesCaracteristicas()
    {
        return $this->hasMany('App\DetallesCaracteristica', 'id_caracteristica', 'id_caracteristica');
    }
}
