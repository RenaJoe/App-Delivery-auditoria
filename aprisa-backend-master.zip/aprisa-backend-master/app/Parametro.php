<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_parametro
 * @property string $nombre
 * @property float $valor
 * @property string $created_at
 * @property string $updated_at
 */
class Parametro extends Model
{
    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_parametro';

    /**
     * @var array
     */
    protected $fillable = ['nombre','variable_name', 'valor', 'created_at', 'updated_at'];

}
