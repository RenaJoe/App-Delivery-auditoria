<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_datos_adicionales
 * @property int $id_usuario
 * @property string $ciudad
 * @property string $fecha_nacimiento
 * @property string $tipo_vehiculo
 * @property string $foto_cedula
 * @property User $user
 */
class DatosAdicionales extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_datos_adicionales';

    /**
     * @var array
     */
    protected $fillable = ['id_usuario', 'genero', 'ciudad', 'fecha_nacimiento', 'tipo_vehiculo', 'foto_cedula'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_usuario');
    }
}
