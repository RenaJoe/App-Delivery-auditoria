<?php

namespace App;

use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * @property int $id
 * @property int $id_rol
 * @property string $nombre
 * @property string $apellido
 * @property string $cedula
 * @property string $telefono
 * @property string $direccion
 * @property string $foto
 * @property string $estado
 * @property string $email
 * @property string $password
 * @property string $email_verified_at
 * @property string $remember_token
 * @property string $id_device
 * @property string $created_at
 * @property string $updated_at
 * @property Role $role
 * @property DatosAdicionale[] $datosAdicionales
 * @property Negocio[] $negocios
 * @property Pedido[] $pedidos
 * @property RepartidorPedido[] $repartidorPedidos
 */

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['id_rol', 'nombre', 'apellido', 'cedula', 'telefono', 'foto', 'estado', 'email', 'password', 'email_verified_at', 'remember_token', 'id_device', 'created_at', 'updated_at'];


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function role()
    {
        return $this->belongsTo('App\Rol', 'id_rol', 'id_rol');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function negocios()
    {
        return $this->hasMany('App\Negocio', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function datosAdicionales()
    {
        return $this->hasOne('App\DatosAdicionales', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pedidos()
    {
        return $this->hasMany('App\Pedido', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function repartidorPedidos()
    {
        return $this->hasMany('App\RepartidorPedido', 'id_usuario');
    }
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function direcciones()
    {
        return $this->hasMany('App\Direccion', 'id_usuario');
    }
}
