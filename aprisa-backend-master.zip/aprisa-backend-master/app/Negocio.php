<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_negocio
 * @property int $id_usuario
 * @property int $id_tipo_servicio
 * @property string $nombre
 * @property string $codigo
 * @property float $latitud
 * @property float $longitud
 * @property string $foto
 * @property string $direccion
 * @property string $telefono
 * @property float $calificacion_promedio
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 * @property TiposServicio $tiposServicio
 * @property Calificacione[] $calificaciones
 * @property Categoria[] $categorias
 * @property Horario[] $horarios
 * @property Pedido[] $pedidos
 */
class Negocio extends Model
{
    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_negocio';

    /**
     * @var array
     */
    protected $fillable = ['id_usuario', 'id_tipo_servicio', 'nombre', 'codigo', 'latitud', 'longitud', 'foto','tiempo_preparacion', 'direccion', 'telefono', 'calificacion_promedio', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User', 'id_usuario');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function tiposServicio()
    {
        return $this->belongsTo('App\TiposServicio', 'id_tipo_servicio', 'id_tipo_servicio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function calificaciones()
    {
        return $this->hasMany('App\Calificacione', 'id_negocio', 'id_negocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function categorias()
    {
        return $this->hasMany('App\Categoria', 'id_negocio', 'id_negocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function horarios()
    {
        return $this->hasMany('App\Horario', 'id_negocio', 'id_negocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pedidos()
    {
        return $this->hasMany('App\Pedido', 'id_negocio', 'id_negocio');
    }
}
