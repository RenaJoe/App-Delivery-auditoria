<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_extra
 * @property int $id_producto
 * @property string $nombre
 * @property string $foto
 * @property float $valor
 * @property string $created_at
 * @property string $updated_at
 * @property Producto $producto
 * @property DetallesExtra[] $detallesExtras
 */
class Extra extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_extra';

    /**
     * @var array
     */
    protected $fillable = ['id_producto', 'nombre', 'foto', 'valor', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function producto()
    {
        return $this->belongsTo('App\Producto', 'id_producto', 'id_producto');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function detallesExtras()
    {
        return $this->hasMany('App\DetallesExtra', 'id_extra', 'id_extra');
    }
}
