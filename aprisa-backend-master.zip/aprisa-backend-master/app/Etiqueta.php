<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_etiqueta
 * @property string $nombre
 * @property string $created_at
 * @property string $updated_at
 * @property EtiquetaNegocio[] $etiquetaNegocios
 */
class Etiqueta extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_etiqueta';

    /**
     * @var array
     */
    protected $fillable = ['nombre', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function etiquetaNegocios()
    {
        return $this->hasMany('App\EtiquetaNegocio', 'id_etiqueta', 'id_etiqueta');
    }
}
