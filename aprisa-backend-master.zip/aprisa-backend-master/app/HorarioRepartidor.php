<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HorarioRepartidor extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'horarios_repartidor';
    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'id_horario';

    /**
     * @var array
     */
    protected $fillable = ['id_negocio', 'dia', 'inicio', 'fin'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function negocio()
    {
        return $this->belongsTo('App\user', 'id_negocio', 'id');
    }
}
