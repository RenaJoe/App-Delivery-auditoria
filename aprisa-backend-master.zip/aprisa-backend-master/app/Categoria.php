<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id_categoria
 * @property int $id_negocio
 * @property string $nombre
 * @property string $descripcion
 * @property Negocio $negocio
 * @property Producto[] $productos
 */
class Categoria extends Model
{
    /**
     * The primary key for the model.
     * 
     * @var string
     */
    protected $primaryKey = 'id_categoria';

    /**
     * @var array
     */
    protected $fillable = ['id_negocio', 'nombre', 'descripcion'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function negocio()
    {
        return $this->belongsTo('App\Negocio', 'id_negocio', 'id_negocio');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productos()
    {
        return $this->hasMany('App\Producto', 'id_categoria', 'id_categoria');
    }
}
