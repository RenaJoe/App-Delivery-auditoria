<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

/*routes for login and register */

Route::group([
    'prefix' => 'auth'
], function () {
    Route::post('login', 'Auth\AuthController@login')->name('login');
    Route::post('loginRepartidor', 'Auth\AuthController@loginRepartidor')->name('loginRepartidor');
    Route::post('register', 'Auth\AuthController@register');
    Route::post('registerRepartidor', 'Auth\AuthController@registerRepartidor');
    Route::post('loginSuperAdmin', 'Auth\AuthController@loginSuperAdmin');
    Route::get('allUsers', 'Auth\AuthController@allUsers');
    Route::get('allRepartidores', 'Auth\AuthController@allRepartidores');
    Route::put('updateUser/{id}', 'Auth\AuthController@updateUser');
    Route::put('updateRepartidor/{id}', 'Auth\AuthController@updateRepartidor');
    Route::put('updateEstadoUser/{id}', 'Auth\AuthController@updateEstadoUser');
    Route::group([
        'middleware' => 'auth:api'
    ], function () {
        Route::get('logout', 'Auth\AuthController@logout');
        Route::get('user', 'Auth\AuthController@user');
    });
});

/* routes for negocios*/
Route::get('negocios', 'NegociosController@index');
Route::get('negocios/{id}', 'NegociosController@show');
Route::get('negociosByTipoServicio/{id}', 'NegociosController@negociosByTipoServicio');
Route::get('negociosByUser/{id}', 'NegociosController@showByUserId');
Route::get('negociosByNombre/{nombre}', 'NegociosController@showByNombre');
Route::post('negocios', 'NegociosController@store');
Route::put('negocios/{id}', 'NegociosController@update');
Route::put('negocioTiempoPreparacion/{id}', 'NegociosController@updateTiempoPreparacion');
Route::delete('negocios/{id}', 'NegociosController@destroy');

/* routes for categorias*/
Route::get('categorias', 'CategoriasController@index');
Route::get('categorias/{id}', 'CategoriasController@show');
Route::get('categoriasOnly/{id}', 'CategoriasController@showOnlyCategoria');
Route::post('categorias', 'CategoriasController@store');
Route::put('categorias/{id}', 'CategoriasController@update');
Route::delete('categorias/{id}', 'CategoriasController@destroy');

/* routes for productos*/
Route::get('productos', 'ProductosController@index');
Route::get('productos/{id}', 'ProductosController@show');
Route::get('productosOferta/', 'ProductosController@showProductosOferta');
Route::get('productosByNombre/{nombre}', 'ProductosController@showByNombre');
Route::post('productos', 'ProductosController@store');
Route::put('productos/{id}', 'ProductosController@update');
Route::put('productosUpdateOferta/{id}', 'ProductosController@updateOferta');
Route::delete('productos/{id}', 'ProductosController@destroy');

/*routes for pedidos*/
Route::get('pedidos', 'PedidosController@index');
Route::get('pedidos/{id}', 'PedidosController@show');
Route::get('pedidosByNegocio/{id}', 'PedidosController@showByNegocio');
Route::get('pedidosNegocio/{id}', 'PedidosController@pedidosAndNegocio');
Route::get('pedidosByUser/{id}', 'PedidosController@showByUser');
Route::post('pedidos', 'PedidosController@store');
Route::put('updateEstadoPedido/{id}', 'PedidosController@updateEstadoPedido');
Route::put('pedidos/{id}', 'PedidosController@update');
Route::delete('pedidos/{id}', 'PedidosController@destroy');

/* routes for detalles*/
Route::get('detalles', 'DetallesController@index');
Route::get('detalles/{id}', 'DetallesController@show');
Route::get('detallesByPedido/{id}', 'DetallesController@showDetallesByPedido');
Route::post('detalles', 'DetallesController@store');
Route::put('detalles/{id}', 'DetallesController@update');
Route::delete('detalles/{id}', 'DetallesController@destroy');

/* routes for geolocalizaciones*/
Route::get('geolocalizaciones', 'GeolocalizacionController@index');
Route::get('geolocalizaciones/{id}', 'GeolocalizacionController@show');
Route::get('geolocalizacionesByPedido/{id}', 'GeolocalizacionController@showByPedido');
Route::post('geolocalizaciones', 'GeolocalizacionController@store');
Route::put('geolocalizaciones/{id}', 'GeolocalizacionController@update');
Route::delete('geolocalizaciones/{id}', 'GeolocalizacionController@destroy');

/* routes for horarios*/
Route::get('horarios', 'HorariosController@index');
Route::get('horarios/{id}', 'HorariosController@show');
Route::get('horariosByNegocioId/{id_negocio}', 'HorariosController@horariosByNegocioId');
Route::post('horarios', 'HorariosController@store');
Route::put('horarios/{id}', 'HorariosController@update');
Route::delete('horarios/{id}', 'HorariosController@destroy');

/* routes to caracteristicas */
Route::get('caracteristicas/{id}', 'CaracteristicasController@show');
Route::post('caracteristicas', 'CaracteristicasController@store');
Route::put('caracteristicas/{id}', 'CaracteristicasController@update');
Route::get('caracteristicasByProducto/{id}', 'CaracteristicasController@showByIdProducto');
Route::delete('caracteristicas/{id}', 'CaracteristicasController@destroy');

/* routes to extras */
Route::get('extras/{id}', 'ExtrasController@show');
Route::post('extras', 'ExtrasController@store');
Route::put('extras/{id}', 'ExtrasController@update');
Route::get('extrasByProducto/{id}', 'ExtrasController@showByIdProducto');
Route::delete('extras/{id}', 'ExtrasController@destroy');

/* routes to detalles extras*/
Route::post('detallesExtras', 'DetallesExtrasController@store');

/* routes to caracteristicas extras*/
Route::post('detallesCarateristicas', 'DetallesCaracteristicasController@store');

/*repartidor pedidos */
Route::post('repartidorPedidos', 'RepartidorPedidosController@store');
Route::get('repartidorPedidos/{id}', 'RepartidorPedidosController@show');

/* routes for direcciones*/
Route::get('direcciones', 'DireccionesController@index');
Route::get('direcciones/{id}', 'DireccionesController@show');
Route::get('direccionesByUserId/{id}', 'DireccionesController@showByIdUser');
Route::post('direcciones', 'DireccionesController@store');
Route::put('direcciones/{id}', 'DireccionesController@update');
Route::delete('direcciones/{id}', 'DireccionesController@destroy');

/* routes for parametros*/
Route::get('parametros', 'ParametrosController@index');
Route::get('parametros/{id}', 'ParametrosController@show');
Route::post('parametros', 'ParametrosController@store');
Route::put('parametros/{id}', 'ParametrosController@update');
Route::delete('parametros/{id}', 'ParametrosController@destroy');

/* Routes for versions apps */
Route::get('versionClient', 'ParametrosController@showVersionClient');
Route::put('versionClient', 'ParametrosController@updateVersionClient');
Route::get('versionVendor', 'ParametrosController@showVersionVendor');
Route::put('versionVendor', 'ParametrosController@updateVersionVendor');
Route::get('versionRepartidor', 'ParametrosController@showVersionRepartidor');
Route::put('versionRepartidor', 'ParametrosController@updateVersionRepartidor');

/* routes for calificaciones*/
Route::get('calificaciones', 'CalificacionesController@index');
Route::get('calificaciones/{id}', 'CalificacionesController@show');
Route::post('calificaciones', 'CalificacionesController@store');
Route::put('calificaciones/{id}', 'CalificacionesController@update');
Route::delete('calificaciones/{id}', 'CalificacionesController@destroy');

/* routes for facturaciones*/
Route::get('facturaciones', 'FacturacionesController@index');
Route::get('facturaciones/{id}', 'FacturacionesController@show');
Route::get('facturacionesByUserId/{id}', 'FacturacionesController@showByIdUser');
Route::post('facturaciones', 'FacturacionesController@store');
Route::put('facturaciones/{id}', 'FacturacionesController@update');
Route::delete('facturaciones/{id}', 'FacturacionesController@destroy');

/* routes for etiquetas */
Route::get('etiquetas', 'EtiquetasController@index');
Route::get('etiquetas/{id}', 'EtiquetasController@show');
Route::get('etiquetasByNombre/{nombre}', 'EtiquetasController@showByNombre'); // funcionalidad buscador
Route::post('etiquetas', 'EtiquetasController@store');
Route::put('etiquetas/{id}', 'EtiquetasController@update');
Route::delete('etiquetas/{id}', 'EtiquetasController@destroy');

/* routes for etiquetaNegocios */
Route::get('etiquetaNegocios', 'EtiquetaNegociosController@index');
Route::get('etiquetaNegocios/{id}', 'EtiquetaNegociosController@show');
Route::post('etiquetaNegocios', 'EtiquetaNegociosController@store');
Route::put('etiquetaNegocios/{id}', 'EtiquetaNegociosController@update');
Route::delete('etiquetaNegocios/{id}', 'EtiquetaNegociosController@destroy');

/* routes for kushki*/
Route::post('kushkiPayments', 'PaymentsKushkiController@addPaymentCard');


/*
 * routes for banners
 */

Route::get('banners', 'BannersController@index');
Route::get('bannersWithNegocioProducto', 'BannersController@showWithNegocioAndProducto');
Route::get('banners/{id}', 'BannersController@show');
Route::post('banners', 'BannersController@store');
Route::put('banners/{id}', 'BannersController@update');
Route::delete('banners/{id}', 'BannersController@destroy');

/*
 * horarios repartidores
 */

Route::get('horariosRepartidor', 'HorariosController@index');
Route::get('horariosRepartidor/{id}', 'HorariosController@show');
Route::get('horariosRepartidorByUserId/{id_usuario}', 'HorariosController@horariosByUserId');
Route::post('horariosRepartidor', 'HorariosController@store');
Route::put('horariosRepartidor/{id}', 'HorariosController@update');
Route::delete('horariosRepartidor/{id}', 'HorariosController@destroy');
