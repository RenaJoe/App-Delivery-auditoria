<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/clear-cache', function () {
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('config:cache');
    return 'Done';
});

Route::get('/migrate', function () {
    $exitCode = Artisan::call('migrate');
    /*$exitCode = Artisan::call('migrate:refresh');
    $exitCode = Artisan::call('db:seed');
    $exitCode= Artisan::call('migrate', ['--path' => 'vendor/laravel/passport/database/migrations']);*/
    return 'Done';
});

Route::get('/passport',function (){
    $exitCode = Artisan::call('passport:install');
    return $exitCode. 'Done';
});
