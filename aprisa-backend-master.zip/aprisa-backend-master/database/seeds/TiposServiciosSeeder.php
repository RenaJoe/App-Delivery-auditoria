<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TiposServiciosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tipos_servicios')->insert([
            'nombre' => 'Restaurantes',
        ]);
        DB::table('tipos_servicios')->insert([
            'nombre' => 'Vinos y licores',
        ]);
        DB::table('tipos_servicios')->insert([
            'nombre' => 'Tiendas y Supermercados',
        ]);
        DB::table('tipos_servicios')->insert([
            'nombre' => 'Ferreterías',
        ]);
        DB::table('tipos_servicios')->insert([
            'nombre' => 'Tecnología',
        ]);
        DB::table('tipos_servicios')->insert([
            'nombre' => 'Otros',
        ]);
    }
}
