<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class HorariosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*DB::table('horario')->insert([
            'id_negocio' => '1',
            'dia' => 'Lunes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '1',
            'dia' => 'Martes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '1',
            'dia' => 'Miércoles',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '1',
            'dia' => 'Jueves',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '1',
            'dia' => 'Viernes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '1',
            'dia' => 'Sabado',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '1',
            'dia' => 'Domingo',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '2',
            'dia' => 'Lunes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '2',
            'dia' => 'Martes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '2',
            'dia' => 'Miércoles',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '2',
            'dia' => 'Jueves',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '2',
            'dia' => 'Viernes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '2',
            'dia' => 'Sabado',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '2',
            'dia' => 'Domingo',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '3',
            'dia' => 'Lunes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '3',
            'dia' => 'Martes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '3',
            'dia' => 'Miércoles',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '3',
            'dia' => 'Jueves',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '3',
            'dia' => 'Viernes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '3',
            'dia' => 'Sabado',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '3',
            'dia' => 'Domingo',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '4',
            'dia' => 'Lunes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '4',
            'dia' => 'Martes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '4',
            'dia' => 'Miércoles',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '4',
            'dia' => 'Jueves',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '4',
            'dia' => 'Viernes',
            'inicio' => '10:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '4',
            'dia' => 'Sabado',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);
        DB::table('horario')->insert([
            'id_negocio' => '4',
            'dia' => 'Domingo',
            'inicio' => '13:00',
            'fin' => '18:00',
        ]);*/
    }
}
