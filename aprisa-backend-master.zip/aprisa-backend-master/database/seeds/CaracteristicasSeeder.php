<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CaracteristicasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*DB::table('caracteristicas')->insert([
            'id_producto' => '1',
            'nombre' => 'Carne'
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => '1',
            'nombre' => 'Pollo',
        ]);

        DB::table('caracteristicas')->insert([
            'id_producto' => '2',
            'nombre' => 'Carne'
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => '2',
            'nombre' => 'Pollo',
        ]);

        DB::table('caracteristicas')->insert([
            'id_producto' => '3',
            'nombre' => 'Carne'
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => '3',
            'nombre' => 'Pollo',
        ]);*/
        /*
        * Caracteristicas Cusumbos
        */
        DB::table('caracteristicas')->insert([
            'id_producto' => 5,
            'nombre' => 'Lemon - Pepper',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 5,
            'nombre' => 'Hot - Buffalo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 5,
            'nombre' => 'Honey - Mustard',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 5,
            'nombre' => 'Tamarindo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 5,
            'nombre' => 'Bbq',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 5,
            'nombre' => 'Mango',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 5,
            'nombre' => 'Jack Daniels',
        ]);

        DB::table('caracteristicas')->insert([
            'id_producto' => 6,
            'nombre' => 'Lemon - Pepper',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 6,
            'nombre' => 'Hot - Buffalo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 6,
            'nombre' => 'Honey - Mustard',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 6,
            'nombre' => 'Tamarindo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 6,
            'nombre' => 'Bbq',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 6,
            'nombre' => 'Mango',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 6,
            'nombre' => 'Jack Daniels',
        ]);

        DB::table('caracteristicas')->insert([
            'id_producto' => 7,
            'nombre' => 'Lemon - Pepper',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 7,
            'nombre' => 'Hot - Buffalo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 7,
            'nombre' => 'Honey - Mustard',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 7,
            'nombre' => 'Tamarindo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 7,
            'nombre' => 'Bbq',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 7,
            'nombre' => 'Mango',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 7,
            'nombre' => 'Jack Daniels',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 8,
            'nombre' => 'Lemon - Pepper',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 8,
            'nombre' => 'Hot - Buffalo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 8,
            'nombre' => 'Honey - Mustard',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 8,
            'nombre' => 'Tamarindo',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 8,
            'nombre' => 'Bbq',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 8,
            'nombre' => 'Mango',
        ]);
        DB::table('caracteristicas')->insert([
            'id_producto' => 8,
            'nombre' => 'Jack Daniels',
        ]);
    }
}
