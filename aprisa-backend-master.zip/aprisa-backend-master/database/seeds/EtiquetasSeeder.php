<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EtiquetasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('etiquetas')->insert([
            'nombre' => 'Comida rápida',
        ]);
        DB::table('etiquetas')->insert([
            'nombre' => 'Comida italiana',
        ]);
        DB::table('etiquetas')->insert([
            'nombre' => 'Pollo',
        ]);
        DB::table('etiquetas')->insert([
            'nombre' => 'Hamburguesas',
        ]);
        DB::table('etiquetas')->insert([
            'nombre' => 'Pizzas',
        ]);
    }
}
