<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(ParametrosSeeder::class);
        $this->call(EtiquetasSeeder::class);
        $this->call(RolesSeeder::class);
        $this->call(UserSeeder::class);
        $this->call(TiposServiciosSeeder::class);
        $this->call(NegociosSeeder::class);
        $this->call(CategoriasSeeder::class);
        $this->call(ProductosSeeder::class);
        $this->call(HorariosSeeder::class);
        $this->call(ExtrasSeeder::class);
        $this->call(CaracteristicasSeeder::class);
        // $this->call(PedidosSeeder::class);
        // $this->call(DetallesSeeder::class);
    }
}
