<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*DB::table('users')->insert([
            'id_rol' => '2',
            'nombre' => 'admin1',
            'apellido' => 'admin1',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'admin1@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('admin1'),
        ]);
        DB::table('users')->insert([
            'id_rol' => '2',
            'nombre' => 'admin2',
            'apellido' => 'admin2',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'admin2@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('admin2')
        ]);
        DB::table('users')->insert([
            'id_rol' => '2',
            'nombre' => 'admin3',
            'apellido' => 'admin3',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'admin3@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('admin3'),
        ]);
        DB::table('users')->insert([
            'id_rol' => '2',
            'nombre' => 'admin4',
            'apellido' => 'admin4',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'admin4@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('admin4'),
        ]);*/
        DB::table('users')->insert([
            'id_rol' => '2',
            'nombre' => 'Mi rey',
            'apellido' => 'Mi Rey',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'mirey@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('mirey123456'),
        ]);
        /*
        * Cusumbos User
        */
        DB::table('users')->insert([
            'id_rol' => '2',
            'nombre' => 'Cusumbos',
            'apellido' => 'Cusumbos',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'cusumbos@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('cusumbos123456'),
        ]);
        /*
         * Noches de arabia User
         */
        DB::table('users')->insert([
            'id_rol' => '2',
            'nombre' => 'Noches De Arabia',
            'apellido' => 'Noches De Arabia',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'nochesadearabia@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('nochesdearabia123456'),
        ]);

        DB::table('users')->insert([
            'id_rol' => '1',
            'nombre' => 'postman',
            'apellido' => 'postman',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'postman@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('postman'),
        ]);
        DB::table('users')->insert([
            'id_rol' => '1',
            'nombre' => 'Marcelo',
            'apellido' => 'M',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'marcelo@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('marcelo'),
        ]);
        DB::table('users')->insert([
            'id_rol' => '3',
            'nombre' => 'repartidor',
            'apellido' => 'repartidor',
            'cedula' => '1002003001',
            'telefono' => '0987654321',

            'email' => 'repartidor@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('repartidor'),
        ]);
        DB::table('users')->insert([
            'id_rol' => 4,
            'nombre' => 'admin web',
            'apellido' => 'admin web',
            'cedula' => '1002003001',
            'telefono' => '0987654321',
            'email' => 'adminweb@gmail.com',
            'estado' => 'aprobado',
            'password' => bcrypt('adminweb'),
        ]);
    }
}
