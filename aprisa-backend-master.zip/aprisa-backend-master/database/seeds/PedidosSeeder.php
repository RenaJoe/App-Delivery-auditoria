<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PedidosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('pedidos')->insert([
            'id_usuario' => '5',
            'id_negocio' => '1',
            'total' => '100',
            'observaciones' => 'ninguna',
            'tipo_pago' => 'efectivo',
            'direccion' => 'Av. Mariano Acosta 2-654',
            'estado' => 'Recibido',
            'id_device' => '650bcbac-32b5-4b6e-ab4e-560d767f492f',
        ]);
        DB::table('pedidos')->insert([
            'id_usuario' => '6',
            'id_negocio' => '1',
            'total' => '25',
            'observaciones' => 'ninguna',
            'tipo_pago' => 'efectivo',
            'direccion' => 'Av. Colón 2-654',
            'estado' => 'Recibido',
            'id_device' => '650bcbac-32b5-4b6e-ab4e-560d767f492f',
        ]);
    }
}
