<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ParametrosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('parametros')->insert([
            'nombre' => 'tarifa minima',
            'valor' => "1.25",
        ]);
        DB::table('parametros')->insert([
            'nombre' => 'valor km extra',
            'valor' => "0.50",
        ]);
        DB::table('parametros')->insert([
            'nombre' => 'aprisa cliente version',
            'variable_name' => 'client_version',
            'valor' => "0.0.1",
        ]);
        DB::table('parametros')->insert([
            'nombre' => 'aprisa negocio version',
            'variable_name' => 'vendor_version',
            'valor' => "0.0.2",
        ]);
        DB::table('parametros')->insert([
            'nombre' => 'aprisa repartidor version',
            'variable_name' => 'carrier_version',
            'valor' => "0.0.1",
        ]);
    }
}
