<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class CategoriasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*DB::table('categorias')->insert([
            'id_negocio' => '1',
            'nombre' => 'Hamburguesas',
            'descripcion' => 'hamburguesas simples',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '1',
            'nombre' => 'combos',
            'descripcion' => 'todos los combos',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '1',
            'nombre' => 'bebidas',
            'descripcion' => 'bebidas nutritivas',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '2',
            'nombre' => 'Hamburguesas',
            'descripcion' => 'hamburguesas simples',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '2',
            'nombre' => 'combos',
            'descripcion' => 'todos los combos',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '2',
            'nombre' => 'bebidas',
            'descripcion' => 'bebidas nutritivas',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '2',
            'nombre' => 'postres',
            'descripcion' => 'caseros',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '3',
            'nombre' => 'Hamburguesas',
            'descripcion' => 'hamburguesas simples',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '3',
            'nombre' => 'combos',
            'descripcion' => 'todos los combos',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '3',
            'nombre' => 'bebidas',
            'descripcion' => 'bebidas nutritivas',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '3',
            'nombre' => 'postres',
            'descripcion' => 'caseros',
        ]);*/
        /*
        Mi REY Categorias - ID 12
        */
        DB::table('categorias')->insert([
            'id_negocio' => '1',
            'nombre' => 'Salsas, Condimentos, Sopas',
            'descripcion' => 'caseros',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '1',
            'nombre' => 'Enlatados, Conservas',
            'descripcion' => 'caseros',
        ]);
        /*
        * Cusumbos
        */
        DB::table('categorias')->insert([
            'id_negocio' => '2',
            'nombre' => 'Alitas',
            'descripcion' => 'Alitas',
        ]);
        /*
         * Noches de Arabia
         */

        DB::table('categorias')->insert([
            'id_negocio' => '3',
            'nombre' => 'Shawarma',
            'descripcion' => 'Shawarma',
        ]);
        DB::table('categorias')->insert([
            'id_negocio' => '3',
            'nombre' => 'Combos',
            'descripcion' => 'Combos',
        ]);

    }
}
