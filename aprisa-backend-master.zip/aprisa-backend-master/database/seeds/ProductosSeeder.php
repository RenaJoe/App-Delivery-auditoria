<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*DB::table('productos')->insert([
            'id_categoria' => '1',
            'nombre' => 'Hamburguesa simple',
            'descripcion' => 'hamburguesa con papas y cola',
            'precio' => '2.50',
            'precio_oferta' => '2.00',
            'oferta' => true,
            'limitante' => 1,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2FBetter%20Burgers_2019-04-10_9244_TSUCALAS.jpg?alt=media&token=1c70ec93-e39e-40eb-a512-c628d055d5f2',
            'tipo_foto' => '.jpg',
            'estado' => 'true',
        ]);
        DB::table('productos')->insert([
            'id_categoria' => '1',
            'nombre' => 'Hamburguesa doble',
            'descripcion' => 'hamburguesa sola',
            'precio' => '3.00',
            'precio_oferta' => '2.50',
            'oferta' => false,
            'limitante' => 1,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2FburgerDoble.jpg?alt=media&token=22f17c5e-9cfc-4e93-9e92-acb4bceaf805',
            'tipo_foto' => '.jpg',
            'estado' => 'true',
        ]);
        DB::table('productos')->insert([
            'id_categoria' => '1',
            'nombre' => 'Hamburguesa doble',
            'descripcion' => 'hamburguesa doble con papas y cola',
            'precio' => '4.20',
            'precio_oferta' => '3.50',
            'oferta' => true,
            'limitante' => 1,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fcheeseburger-meal.png?alt=media&token=a0362e8c-e9d9-4b2e-b721-766f7865179f',
            'tipo_foto' => '.jpg',
            'estado' => 'true',
        ]);*/

        /*
        Productos Mi Rey
        */
        DB::table('productos')->insert([
            'id_categoria' => '1',
            'nombre' => 'Salsa de tomate',
            'descripcion' => 'Salsa de tomate los andes 396G',
            'precio' => '1.65',
            'precio_oferta' => '1.65',
            'oferta' => false,
            'limitante' => 1,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2FSalsa-de-Tomate-Los-Andes-395-Frasco-Vidrio.jpg?alt=media&token=ba1e8a05-0b2e-4320-abe9-d8e9b91814ca',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);

        DB::table('productos')->insert([
            'id_categoria' => '1',
            'nombre' => 'Salsa de tomate',
            'descripcion' => 'Gustadina Salsa tomate 100G',
            'precio' => '0.5',
            'precio_oferta' => '0.5',
            'oferta' => false,
            'limitante' => 1,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2FSalsa%20de%20tomate%20100%20g.png?alt=media&token=26eff360-0a13-4169-9247-fe2c63348295',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);
        DB::table('productos')->insert([
            'id_categoria' => '2',
            'nombre' => 'Frejol Rosado',
            'descripcion' => 'Frejol Rosado Facundo 425G',
            'precio' => '1.3',
            'precio_oferta' => '1.3',
            'oferta' => false,
            'limitante' => 1,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Ffrejol-rosado-facundo.jpg?alt=media&token=50735809-179b-4e9c-ab2a-f2231977bc19',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);
        DB::table('productos')->insert([
            'id_categoria' => '2',
            'nombre' => 'Atún Real TUN TUN',
            'descripcion' => 'Atun real 80G x 3',
            'precio' => '2.3',
            'precio_oferta' => '2.3',
            'oferta' => false,
            'limitante' => 1,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fatun%20real%20tuntun.jpg?alt=media&token=ae9c3050-88c4-4c4a-8b35-c464b8ca650b',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);
        /*
         * Productos Cusumbos
         */
        DB::table('productos')->insert([
            'id_categoria' => '3',
            'nombre' => 'Alitas Cusumbos',
            'descripcion' => '6 Unidades de Alitas + Papas Fritas + Ensalada y Salsas',
            'precio' => '7.50',
            'precio_oferta' => '7.50',
            'oferta' => false,
            'limitante' => 2,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Falitas1.jpg?alt=media&token=d7751bd1-30a3-4c83-8d2e-f0398e77fd08',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);

        DB::table('productos')->insert([
            'id_categoria' => '3',
            'nombre' => 'Alitas Cusumbos',
            'descripcion' => '10 Unidades de Alitas + Papas Fritas + Ensalada y Salsas',
            'precio' => '11.50',
            'precio_oferta' => '11.50',
            'oferta' => false,
            'limitante' => 2,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Falitas1.jpg?alt=media&token=d7751bd1-30a3-4c83-8d2e-f0398e77fd08',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);
        DB::table('productos')->insert([
            'id_categoria' => '3',
            'nombre' => 'Alitas Cusumbos',
            'descripcion' => '16 Unidades de Alitas + Papas Fritas + Ensalada y Salsas',
            'precio' => '16.50',
            'precio_oferta' => '16.50',
            'oferta' => false,
            'limitante' => 2,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Falitas1.jpg?alt=media&token=d7751bd1-30a3-4c83-8d2e-f0398e77fd08',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);
        DB::table('productos')->insert([
            'id_categoria' => '3',
            'nombre' => 'Alitas Cusumbos',
            'descripcion' => '22 Unidades de Alitas + Papas Fritas + Ensalada y Salsas',
            'precio' => '23.50',
            'precio_oferta' => '23.50',
            'oferta' => false,
            'limitante' => 2,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Falitas1.jpg?alt=media&token=d7751bd1-30a3-4c83-8d2e-f0398e77fd08',
            'tipo_foto' => '.jpg',
            'estado' => true,
            /*
             * Productos Noches de arabia
             */
        ]);
        DB::table('productos')->insert([
            'id_categoria' => 4,
            'nombre' => 'Shawarma',
            'descripcion' => 'Pan arabe + Pollo picado de Shawarma + ensalada + Salsa Especial',
            'precio' => 2.50,
            'precio_oferta' => 2.50,
            'oferta' => false,
            'limitante' => 0,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fshawarma.jpg?alt=media&token=aa0d5969-a1e3-4efa-928b-47ebd77d1b5d',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);
        DB::table('productos')->insert([
            'id_categoria' => 4,
            'nombre' => 'Shawarma Especial',
            'descripcion' => 'Shawarma Especial + Papas',
            'precio' => 3,
            'precio_oferta' => 3,
            'oferta' => false,
            'limitante' => 0,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fshawarma-especial.jpg?alt=media&token=6c4bbcef-c9f4-423b-aeaf-a7d872d999e5',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);

        DB::table('productos')->insert([
            'id_categoria' => 4,
            'nombre' => 'Shawarma Abierto',
            'descripcion' => 'Shawarma Abierto',
            'precio' => 4.50,
            'precio_oferta' => 4.50,
            'oferta' => false,
            'limitante' => 0,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fshawarma-abierto.jpg?alt=media&token=20a91138-e3e2-4cff-b6f9-3532da6f7974',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);

        DB::table('productos')->insert([
            'id_categoria' => 5,
            'nombre' => 'Combo Amigo',
            'descripcion' => '4 Hamburguesas + 10 Alitas BBQ + Porción de Papas + 3 Colas Personales ',
            'precio' => 4.50,
            'precio_oferta' => 4.50,
            'oferta' => false,
            'limitante' => 0,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fcombo-amigo.jpg?alt=media&token=f0e15c22-979e-448b-8bde-0c9418d9088b',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);

        DB::table('productos')->insert([
            'id_categoria' => 5,
            'nombre' => 'Combo Snack Habibi',
            'descripcion' => '2 Shawarmas + 6 Alitas BBQ + Porción de Papas + 2 Colas Personales ',
            'precio' => 12.50,
            'precio_oferta' => 12.50,
            'oferta' => false,
            'limitante' => 0,
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fcombo-snack-habibi.jpg?alt=media&token=524494a3-9f99-443b-b913-d5d3519c0e28',
            'tipo_foto' => '.jpg',
            'estado' => true,
        ]);

    }
}
