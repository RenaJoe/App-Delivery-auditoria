<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetallesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('detalles')->insert([
            'id_producto' => '1',
            'id_pedido' => '1',
            'cantidad' => '1',
            'total' => '2.5'
        ]);
        DB::table('detalles')->insert([
            'id_producto' => '2',
            'id_pedido' => '1',
            'cantidad' => '1',
            'total' => '3'
        ]);
        DB::table('detalles')->insert([
            'id_producto' => '3',
            'id_pedido' => '1',
            'cantidad' => '2',
            'total' => '9'
        ]);
        DB::table('detalles')->insert([
            'id_producto' => '1',
            'id_pedido' => '2',
            'cantidad' => '1',
            'total' => '2.5'
        ]);
        DB::table('detalles')->insert([
            'id_producto' => '2',
            'id_pedido' => '2',
            'cantidad' => '1',
            'total' => '3'
        ]);
        DB::table('detalles')->insert([
            'id_producto' => '3',
            'id_pedido' => '2',
            'cantidad' => '2',
            'total' => '9'
        ]);
    }
}
