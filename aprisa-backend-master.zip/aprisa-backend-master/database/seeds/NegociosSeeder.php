<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class NegociosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*
        * RESTAURANTES
        */
       /* DB::table('negocios')->insert([
            'id_usuario' => 1,
            'id_tipo_servicio' => 1,
            'nombre' => 'KFC',
            'codigo' => '',
            'latitud' => '0.3708485',
            'longitud' => '-78.1179056',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2FKFC.jpg?alt=media&token=a236f998-cfb1-4e4d-92b0-7a782068d860',
            'direccion' => 'Ibarra',
            'telefono' => '0987654321',
        ]);
        DB::table('negocios')->insert([
            'id_usuario' => 2,
            'id_tipo_servicio' => 1,
            'nombre' => 'TROPI BURGER',
            'codigo' => '',
            'latitud' => '0.3465241',
            'longitud' => '-78.1291048',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2FTropiburguer.jpg?alt=media&token=bce52802-4b18-4815-b99f-b6163309ca56',
            'direccion' => 'Ibarra',
            'telefono' => '0987654321',
        ]);
        DB::table('negocios')->insert([
            'id_usuario' => 3,
            'id_tipo_servicio' => 1,
            'nombre' => 'Menestras del negro',
            'codigo' => '',
            'latitud' => '0.3383623',
            'longitud' => '-78.1197329',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2FMenestras-del-Negro-logo.jpg?alt=media&token=3e3f4aaa-3e9a-4407-8c60-2eeecda2ee94',
            'direccion' => 'Ibarra',
            'telefono' => '0987654321',
        ]);
        DB::table('negocios')->insert([
            'id_usuario' => 4,
            'id_tipo_servicio' => 1,
            'nombre' => 'Super Sánduche',
            'codigo' => '',
            'latitud' => '0.3382204',
            'longitud' => '-78.137135',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2FsuperSanduche.jpg?alt=media&token=d0d4e538-3434-4737-8eb6-d4ca9e3202e3',
            'direccion' => 'Ibarra',
            'telefono' => '0987654321',
        ]);*/

        /*
        * Super Mercados
        */
        DB::table('negocios')->insert([
            'id_usuario' => 1,
            'id_tipo_servicio' => 3, //supermercado
            'nombre' => 'Supermercado MI REY',
            'codigo' => '',
            'latitud' => '0.3382204',
            'longitud' => '-78.137135',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/negocios%2Flogo-mi-rey.jpg?alt=media&token=b3133863-f67d-4070-a330-67f631f369d3',
            'direccion' => 'Ibarra',
            'telefono' => '0987654321',
        ]);

         /*
        * CUSUMBOS
        */
        DB::table('negocios')->insert([
            'id_usuario' => 2,
            'id_tipo_servicio' => 1,
            'nombre' => 'Cusumbos Wings',
            'codigo' => '',
            'latitud' => '0.3342315',
            'longitud' => '-78.1210054',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/negocios%2Flogo-cusumbos.jpg?alt=media&token=dd64f268-f299-4670-88c2-1e21da222368',
            'direccion' => 'Ibarra',
            'telefono' => '0987654321',
        ]);

        /*
        * Noches de Arabia
        */
        DB::table('negocios')->insert([
            'id_usuario' => 3,
            'id_tipo_servicio' => 1,
            'nombre' => 'Noches de Arabia',
            'codigo' => '',
            'latitud' => '0.3449457',
            'longitud' => '-78.1191868',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/negocios%2Flogo-noches-arabia.jpg?alt=media&token=b602b414-de91-4f84-9d4d-3473fb4eb569',
            'direccion' => 'Ibarra',
            'telefono' => '0987654321',
        ]);
    }
}
