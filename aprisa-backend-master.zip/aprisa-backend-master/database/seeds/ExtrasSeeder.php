<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ExtrasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        /*DB::table('extras')->insert([
            'id_producto' => '1',
            'nombre' => 'papas fritas',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpapasfritas.jpg?alt=media&token=aa9759c2-1157-4042-bcf5-05e06ec4f2c7',
            'valor' => '1.00',
        ]);

        DB::table('extras')->insert([
            'id_producto' => '1',
            'nombre' => 'gaseosa',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpepsicola.jpg?alt=media&token=a2220514-8c84-47ca-8708-30b99d201c93',
            'valor' => '1.50',
        ]);
        DB::table('extras')->insert([
            'id_producto' => '2',
            'nombre' => 'papas fritas',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpapasfritas.jpg?alt=media&token=aa9759c2-1157-4042-bcf5-05e06ec4f2c7',
            'valor' => '1.00',
        ]);

        DB::table('extras')->insert([
            'id_producto' => '2',
            'nombre' => 'gaseosa',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpepsicola.jpg?alt=media&token=a2220514-8c84-47ca-8708-30b99d201c93',
            'valor' => '1.50',
        ]);
        DB::table('extras')->insert([
            'id_producto' => '3',
            'nombre' => 'papas fritas',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpapasfritas.jpg?alt=media&token=aa9759c2-1157-4042-bcf5-05e06ec4f2c7',
            'valor' => '1.00',
        ]);

        DB::table('extras')->insert([
            'id_producto' => '3',
            'nombre' => 'gaseosa',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpepsicola.jpg?alt=media&token=a2220514-8c84-47ca-8708-30b99d201c93',
            'valor' => '1.50',
        ]);*/

        /*
        * Cusumbos
        */
        DB::table('extras')->insert([
            'id_producto' => 5,
            'nombre' => 'Papas Fritas',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpapasfritas.jpg?alt=media&token=aa9759c2-1157-4042-bcf5-05e06ec4f2c7',
            'valor' => '1.00',
        ]);

        DB::table('extras')->insert([
            'id_producto' => 5,
            'nombre' => 'Gaseosa Personal 400ml',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fcoca-cola400ml.jpg?alt=media&token=b4427ba6-dbcf-4a8b-aae2-2073693de07d',
            'valor' => '1.50',
        ]);
        DB::table('extras')->insert([
            'id_producto' => 6,
            'nombre' => 'Papas Fritas',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpapasfritas.jpg?alt=media&token=aa9759c2-1157-4042-bcf5-05e06ec4f2c7',
            'valor' => '1.00',
        ]);

        DB::table('extras')->insert([
            'id_producto' => 6,
            'nombre' => 'Gaseosa Personal 400ml',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fcoca-cola400ml.jpg?alt=media&token=b4427ba6-dbcf-4a8b-aae2-2073693de07d',
            'valor' => '1.50',
        ]);
        DB::table('extras')->insert([
            'id_producto' => 7,
            'nombre' => 'Papas Fritas',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpapasfritas.jpg?alt=media&token=aa9759c2-1157-4042-bcf5-05e06ec4f2c7',
            'valor' => '1.00',
        ]);

        DB::table('extras')->insert([
            'id_producto' => 7,
            'nombre' => 'Gaseosa Personal 400ml',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fcoca-cola400ml.jpg?alt=media&token=b4427ba6-dbcf-4a8b-aae2-2073693de07d',
            'valor' => '1.50',
        ]);
        DB::table('extras')->insert([
            'id_producto' => 8,
            'nombre' => 'Papas Fritas',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/ozi-push.appspot.com/o/imagenes%2Fpapasfritas.jpg?alt=media&token=aa9759c2-1157-4042-bcf5-05e06ec4f2c7',
            'valor' => '1.00',
        ]);

        DB::table('extras')->insert([
            'id_producto' => 8,
            'nombre' => 'Gaseosa Personal 400ml',
            'foto' => 'https://firebasestorage.googleapis.com/v0/b/aprisa-app.appspot.com/o/productos%2Fcoca-cola400ml.jpg?alt=media&token=b4427ba6-dbcf-4a8b-aae2-2073693de07d',
            'valor' => '1.50',
        ]);
    }
}
