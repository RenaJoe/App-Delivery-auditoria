<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateGeolocalizacionTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('geolocalizacion', function(Blueprint $table)
		{
			$table->integer('id_geolocalizacion', true);
			$table->integer('id_pedido')->nullable();
			$table->float('latitud', 10, 0)->nullable();
			$table->float('longitud', 10, 0)->nullable();
			$table->string('estado', 20)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('geolocalizacion');
	}

}
