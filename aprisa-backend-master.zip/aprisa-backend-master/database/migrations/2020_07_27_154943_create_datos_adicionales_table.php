<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateDatosAdicionalesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('datos_adicionales', function(Blueprint $table)
		{
			$table->integer('id_datos_adicionales', true);
			$table->integer('id_usuario')->nullable();
			$table->string('ciudad', 50)->nullable();
			$table->date('fecha_nacimiento')->nullable();
			$table->string('tipo_vehiculo', 25)->nullable();
			$table->text('foto_cedula')->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('datos_adicionales');
	}

}
