<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePedidosTable extends Migration
{

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('pedidos', function (Blueprint $table) {
			$table->integer('id_pedido', true);
			$table->integer('id_usuario')->nullable();
			$table->integer('id_negocio')->nullable();
			$table->integer('id_direccion')->nullable();
			$table->integer('id_facturacion')->nullable();
			$table->float('subtotal', 10, 0)->nullable();
			$table->float('costo_envio', 10, 0)->nullable();
			$table->float('total', 10, 0)->nullable();
			$table->string('observaciones', 256)->nullable();
			$table->string('tipo_pago', 20)->nullable();
			$table->string('estado', 100)->nullable();
			$table->integer('tiempo_preparacion')->nullable();
			$table->string('id_device', 100)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('pedidos');
	}
}
