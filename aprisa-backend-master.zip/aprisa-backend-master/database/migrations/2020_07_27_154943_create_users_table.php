<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('id_rol')->nullable();
			$table->string('nombre', 50)->nullable();
			$table->string('apellido', 50)->nullable();
			$table->string('cedula', 15)->nullable();
			$table->string('telefono', 15)->nullable();
			$table->text('foto')->nullable();
			$table->string('estado', 20)->nullable();
			$table->string('email', 256)->nullable();
			$table->string('password', 256)->nullable();
			$table->dateTime('email_verified_at')->nullable();
			$table->string('remember_token', 100)->nullable();
			$table->string('id_device', 100)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
