<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddForeignKeysToBannersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('banners', function (Blueprint $table) {
            $table->foreign('id_producto','fk_banners_reference_producto')->references('id_producto')->on('productos')->onUpdate('RESTRICT')->onDelete('RESTRICT');
            $table->foreign('id_negocio','fk_banners_reference_negocio')->references('id_negocio')->on('negocios')->onUpdate('RESTRICT')->onDelete('RESTRICT');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('banners', function (Blueprint $table) {
            $table->dropForeign('fk_banners_reference_producto');
            $table->dropForeign('fk_banners_reference_negocio');
        });
    }
}
