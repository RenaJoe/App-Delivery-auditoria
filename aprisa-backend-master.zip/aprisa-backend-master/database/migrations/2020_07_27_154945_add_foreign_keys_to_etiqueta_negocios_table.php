<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class AddForeignKeysToEtiquetaNegociosTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('etiqueta_negocios', function(Blueprint $table)
		{
			$table->foreign('id_negocio', 'fk_etiqueta_reference_negocios')->references('id_negocio')->on('negocios')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('id_etiqueta', 'fk_etiqueta_reference_etiqueta')->references('id_etiqueta')->on('etiquetas')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('etiqueta_negocios', function(Blueprint $table)
		{
			$table->dropForeign('fk_etiqueta_reference_negocios');
			$table->dropForeign('fk_etiqueta_reference_etiqueta');
		});
	}

}
