<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHorariosRepartidorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('horarios_repartidor', function (Blueprint $table) {
            $table->integer('id_horario_repartidor', true);
            $table->integer('id_usuario')->nullable();
            $table->string('dia', 15)->nullable();
            $table->time('inicio')->nullable();
            $table->time('fin')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('horarios_repartidor');
    }
}
