<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateDireccionesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('direcciones', function(Blueprint $table)
		{
			$table->integer('id_direccion', true);
			$table->integer('id_usuario')->nullable();
			$table->float('latitud', 10, 0)->nullable();
			$table->float('longitud', 10, 0)->nullable();
			$table->string('ciudad', 100)->nullable();
			$table->string('calle', 256)->nullable();
			$table->string('nro', 20)->nullable();
			$table->string('piso', 20)->nullable();
			$table->string('departamento', 20)->nullable();
			$table->string('referencia', 256)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('direcciones');
	}

}
