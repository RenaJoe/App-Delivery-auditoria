<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class AddForeignKeysToHorarioTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('horario', function(Blueprint $table)
		{
			$table->foreign('id_negocio', 'fk_horario_reference_negocios')->references('id_negocio')->on('negocios')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('horario', function(Blueprint $table)
		{
			$table->dropForeign('fk_horario_reference_negocios');
		});
	}

}
