<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddForeignKeysToHorariosRepartidorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('horarios_repartidor', function (Blueprint $table) {
            $table->foreign('id_usuario', 'fk_horarios_rep_reference_users')->references('id')->on('users')->onUpdate('RESTRICT')->onDelete('RESTRICT');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('horarios_repartidor', function (Blueprint $table) {
            $table->dropForeign('fk_horarios_rep_reference_users');
        });
    }
}
