<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class AddForeignKeysToDetallesCaracteristicasTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('detalles_caracteristicas', function(Blueprint $table)
		{
			$table->foreign('id_detalle', 'fk_detalles_reference_detalles')->references('id_detalle')->on('detalles')->onUpdate('RESTRICT')->onDelete('RESTRICT');
			$table->foreign('id_caracteristica', 'fk_detalles_reference_caracter')->references('id_caracteristica')->on('caracteristicas')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('detalles_caracteristicas', function(Blueprint $table)
		{
			$table->dropForeign('fk_detalles_reference_detalles');
			$table->dropForeign('fk_detalles_reference_caracter');
		});
	}

}
