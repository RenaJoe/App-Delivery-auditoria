<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class AddForeignKeysToGeolocalizacionTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('geolocalizacion', function(Blueprint $table)
		{
			$table->foreign('id_pedido', 'fk_geolocal_reference_pedidos')->references('id_pedido')->on('pedidos')->onUpdate('RESTRICT')->onDelete('RESTRICT');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('geolocalizacion', function(Blueprint $table)
		{
			$table->dropForeign('fk_geolocal_reference_pedidos');
		});
	}

}
