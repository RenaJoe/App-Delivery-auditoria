<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateNegociosTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('negocios', function(Blueprint $table)
		{
			$table->integer('id_negocio', true);
			$table->integer('id_usuario')->nullable();
			$table->integer('id_tipo_servicio')->nullable();
			$table->string('nombre', 256)->nullable();
			$table->string('codigo', 25)->nullable();
			$table->float('latitud', 10, 0)->nullable();
			$table->float('longitud', 10, 0)->nullable();
			$table->text('foto')->nullable();
			$table->string('direccion', 256)->nullable();
			$table->string('telefono', 20)->nullable();
			$table->string('tiempo_preparacion')->default('15 - 20min');
			$table->float('calificacion_promedio', 10, 0)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('negocios');
	}

}
