<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
class CreateFacturacionesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('facturaciones', function(Blueprint $table)
		{
			$table->integer('id_facturacion', true);
			$table->integer('id_usuario')->nullable();
			$table->string('tipo_documento', 15)->nullable();
			$table->string('nombre_completo', 256)->nullable();
			$table->string('cedula', 30)->nullable();
			$table->string('telefono', 20)->nullable();
			$table->string('email', 256)->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('facturaciones');
	}

}
