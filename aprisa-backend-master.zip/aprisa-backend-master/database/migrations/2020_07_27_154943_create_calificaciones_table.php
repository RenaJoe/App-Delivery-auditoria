<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCalificacionesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('calificaciones', function(Blueprint $table)
		{
			$table->integer('id_calificacion', true);
			$table->integer('id_negocio')->nullable();
			$table->integer('id_usuario')->nullable();
			$table->string('calificacion', 20)->nullable();
			$table->string('descripcion', 256)->nullable();
			$table->integer('valor')->nullable();
			$table->date('fecha')->nullable();
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('calificaciones');
	}

}
