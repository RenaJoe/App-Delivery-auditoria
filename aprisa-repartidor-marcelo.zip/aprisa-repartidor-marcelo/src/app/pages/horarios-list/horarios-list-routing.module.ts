import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HorariosListPage } from './horarios-list.page';

const routes: Routes = [
  {
    path: '',
    component: HorariosListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HorariosListPageRoutingModule {}
