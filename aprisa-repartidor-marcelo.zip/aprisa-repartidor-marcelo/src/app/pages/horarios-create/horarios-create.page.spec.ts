import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { HorariosCreatePage } from './horarios-create.page';

describe('HorariosCreatePage', () => {
  let component: HorariosCreatePage;
  let fixture: ComponentFixture<HorariosCreatePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HorariosCreatePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(HorariosCreatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
