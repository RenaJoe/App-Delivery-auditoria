import { Injectable } from '@angular/core';
import { Socket } from "ngx-socket-io";

@Injectable({
  providedIn: 'root'
})
export class SocketWebService extends Socket {

  constructor() {
    super({
      url: "https://aprisa-socket.herokuapp.com/",
      // options:{
      //   query:{
      //     pedidoId:{}
      //   }
      // }
    })
    console.log("connect to socket try!!");
    
  }

  emitEvent = (payload = {}) => {
    this.ioSocket.emit('location', payload)

  }
}
