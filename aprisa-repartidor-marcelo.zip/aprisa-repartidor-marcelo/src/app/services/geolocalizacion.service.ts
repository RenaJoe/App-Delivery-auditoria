import { Injectable } from '@angular/core';
import { EnvService } from './env.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GeolocalizacionService {

  constructor(
    private envService: EnvService,
    private http: HttpClient
  ) { }

  createGeolocation(pedido) {
    return this.http.post(this.envService.API_URL + "geolocalizaciones", pedido)
  }
}
